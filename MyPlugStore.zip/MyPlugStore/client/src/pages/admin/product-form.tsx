
import React from "react";
import { useForm } from "react-hook-form";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ArrowLeft } from "lucide-react";

export default function ProductForm() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEdit = id !== "new";

  const { data: product } = useQuery({
    queryKey: [`/api/products/${id}`],
    enabled: isEdit,
  });

  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });

  const { register, handleSubmit, setValue, watch, reset, formState: { errors } } = useForm({
    defaultValues: {
      name: "",
      slug: "",
      description: "",
      price: "",
      comparePrice: "",
      imageUrl: "",
      categoryId: "",
      featured: false,
      trending: false,
      inStock: true,
      badge: "",
    },
  });

  // Update form values when product data is loaded
  React.useEffect(() => {
    if (product) {
      reset({
        name: product.name,
        slug: product.slug,
        description: product.description,
        price: product.price.toString(),
        comparePrice: product.comparePrice?.toString() || "",
        imageUrl: product.imageUrl,
        categoryId: product.categoryId.toString(),
        featured: product.featured,
        trending: product.trending,
        inStock: product.inStock,
        badge: product.badge || "",
      });
    }
  }, [product, reset]);

  const saveMutation = useMutation({
    mutationFn: async (data: any) => {
      const url = isEdit ? `/api/admin/products/${id}` : "/api/admin/products";
      const method = isEdit ? "PUT" : "POST";
      return await apiRequest(method, url, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({
        title: isEdit ? "Product updated" : "Product created",
        description: `The product has been successfully ${isEdit ? "updated" : "created"}.`,
      });
      setLocation("/admin/dashboard");
    },
    onError: () => {
      toast({
        title: "Error",
        description: `Failed to ${isEdit ? "update" : "create"} product. Please try again.`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    saveMutation.mutate({
      ...data,
      categoryId: parseInt(data.categoryId),
      price: parseFloat(data.price),
      comparePrice: data.comparePrice ? parseFloat(data.comparePrice) : null,
    });
  };

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
  };

  return (
    <>
      <Helmet>
        <title>{isEdit ? "Edit Product" : "Add Product"} - Admin - THE PLUG</title>
      </Helmet>

      <div className="bg-slate-50 min-h-screen">
        <div className="container mx-auto px-4 py-8">
          <Button
            variant="ghost"
            className="mb-4"
            onClick={() => setLocation("/admin/dashboard")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>

          <Card>
            <CardHeader>
              <CardTitle>{isEdit ? "Edit Product" : "Add New Product"}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Product Name *</Label>
                    <Input
                      id="name"
                      {...register("name", { required: "Name is required" })}
                      onChange={(e) => {
                        const name = e.target.value;
                        setValue("name", name);
                        setValue("slug", generateSlug(name));
                      }}
                    />
                    {errors.name && <p className="text-sm text-red-500">{errors.name.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="slug">Slug *</Label>
                    <Input
                      id="slug"
                      {...register("slug", { required: "Slug is required" })}
                      readOnly
                    />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="description">Description *</Label>
                    <Textarea
                      id="description"
                      {...register("description", { required: "Description is required" })}
                      rows={4}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="price">Price (KSh) *</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      {...register("price", { required: "Price is required" })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="comparePrice">Compare Price (KSh)</Label>
                    <Input
                      id="comparePrice"
                      type="number"
                      step="0.01"
                      {...register("comparePrice")}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="imageUrl">Image URL *</Label>
                    <Input
                      id="imageUrl"
                      {...register("imageUrl", { required: "Image URL is required" })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="categoryId">Category *</Label>
                    <Select
                      onValueChange={(value) => setValue("categoryId", value)}
                      value={watch("categoryId")}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories?.map((cat: any) => (
                          <SelectItem key={cat.id} value={cat.id.toString()}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="badge">Badge (Optional)</Label>
                    <Input id="badge" {...register("badge")} placeholder="e.g., HOT DEAL" />
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="featured">Featured Product</Label>
                      <Switch
                        id="featured"
                        checked={watch("featured")}
                        onCheckedChange={(checked) => setValue("featured", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="trending">Trending Product</Label>
                      <Switch
                        id="trending"
                        checked={watch("trending")}
                        onCheckedChange={(checked) => setValue("trending", checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="inStock">In Stock</Label>
                      <Switch
                        id="inStock"
                        checked={watch("inStock")}
                        onCheckedChange={(checked) => setValue("inStock", checked)}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button type="submit" disabled={saveMutation.isPending}>
                    {saveMutation.isPending ? "Saving..." : isEdit ? "Update Product" : "Create Product"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setLocation("/admin/dashboard")}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}
