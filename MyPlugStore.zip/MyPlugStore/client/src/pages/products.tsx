import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Product, Category } from "@shared/schema";
import ProductCard from "@/components/products/ProductCard";
import { FilterX, SlidersHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Products() {
  const [location, setLocation] = useLocation();
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);
  
  // Parse query parameters
  const params = new URLSearchParams(location.split('?')[1] || '');
  const categorySlug = params.get('category');
  const searchTerm = params.get('search');
  const featured = params.get('featured');
  const trending = params.get('trending');
  const currentPage = parseInt(params.get('page') || '1', 10);
  const sortBy = params.get('sort') || 'featured';

  // Fetch categories
  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ["/api/categories"],
  });

  // Fetch products with filters
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products", { 
      category: categorySlug, 
      featured: featured === 'true' ? 'true' : undefined,
      trending: trending === 'true' ? 'true' : undefined,
      search: searchTerm
    }],
  });

  // Reset page when filters change
  useEffect(() => {
    const handleResetPage = () => {
      if (currentPage > 1) {
        const newParams = new URLSearchParams(params);
        newParams.delete('page');
        setLocation(`/products?${newParams.toString()}`);
      }
    };

    // Reset page when filters change
    return () => handleResetPage();
  }, [categorySlug, searchTerm, featured, trending, sortBy]);

  // Initialize selected categories
  const [selectedCategories, setSelectedCategories] = useState<string[]>(
    categorySlug ? [categorySlug] : []
  );

  // Handle category selection
  const handleCategoryChange = (slug: string) => {
    let newSelected;
    if (selectedCategories.includes(slug)) {
      newSelected = selectedCategories.filter(cat => cat !== slug);
    } else {
      newSelected = [...selectedCategories, slug];
    }
    setSelectedCategories(newSelected);
    
    const newParams = new URLSearchParams(params);
    if (newSelected.length === 1) {
      newParams.set('category', newSelected[0]);
    } else if (newSelected.length === 0) {
      newParams.delete('category');
    } else {
      // Handle multiple categories (use the first one for now)
      newParams.set('category', newSelected[0]);
    }
    setLocation(`/products?${newParams.toString()}`);
  };

  // Handle sorting change
  const handleSortChange = (value: string) => {
    const newParams = new URLSearchParams(params);
    newParams.set('sort', value);
    setLocation(`/products?${newParams.toString()}`);
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    const newParams = new URLSearchParams(params);
    if (page === 1) {
      newParams.delete('page');
    } else {
      newParams.set('page', page.toString());
    }
    setLocation(`/products?${newParams.toString()}`);
    window.scrollTo(0, 0);
  };

  // Handle clearing all filters
  const handleClearFilters = () => {
    setSelectedCategories([]);
    setLocation('/products');
  };

  // Pagination setup
  const productsPerPage = 12;
  const totalProducts = products?.length || 0;
  const totalPages = Math.ceil(totalProducts / productsPerPage);
  
  // Get current page products
  const getCurrentPageProducts = () => {
    if (!products) return [];
    const startIndex = (currentPage - 1) * productsPerPage;
    const endIndex = startIndex + productsPerPage;
    return products.slice(startIndex, endIndex);
  };

  // Get page title based on filters
  const getPageTitle = () => {
    if (searchTerm) {
      return `Search results for "${searchTerm}"`;
    }
    if (featured === 'true') {
      return "Featured Products";
    }
    if (trending === 'true') {
      return "Trending Products";
    }
    if (categorySlug && categories) {
      const category = categories.find((c: Category) => c.slug === categorySlug);
      if (category) {
        return `${category.name} Products`;
      }
    }
    return "All Products";
  };

  const currentPageProducts = getCurrentPageProducts();
  const pageTitle = getPageTitle();

  return (
    <>
      <Helmet>
        <title>{pageTitle} - MY PLUG</title>
        <meta 
          name="description" 
          content={`Browse our collection of ${pageTitle.toLowerCase()}. Quality items with fast delivery and secure payment options.`} 
        />
        <meta property="og:title" content={`${pageTitle} - MY PLUG`} />
        <meta 
          property="og:description" 
          content={`Browse our collection of ${pageTitle.toLowerCase()}. Quality items with fast delivery and secure payment options.`} 
        />
        <meta property="og:type" content="website" />
      </Helmet>

      <div className="bg-white">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold text-slate-800">{pageTitle}</h1>
              <Button 
                variant="outline" 
                size="sm"
                className="md:hidden"
                onClick={() => setMobileFiltersOpen(!mobileFiltersOpen)}
              >
                <SlidersHorizontal className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </div>

            {searchTerm && (
              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-slate-600">
                  Showing results for: <span className="font-semibold">{searchTerm}</span>
                </p>
              </div>
            )}

            <div className="flex flex-col md:flex-row gap-6">
              {/* Filters Sidebar (Desktop) */}
              <div className="hidden md:block w-full md:w-1/4 lg:w-1/5">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-lg font-semibold">Filters</h2>
                      {(categorySlug || featured || trending || searchTerm) && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={handleClearFilters}
                          className="text-slate-500 hover:text-slate-700"
                        >
                          <FilterX className="h-4 w-4 mr-1" />
                          Clear
                        </Button>
                      )}
                    </div>

                    <Accordion type="single" collapsible className="w-full" defaultValue="categories">
                      <AccordionItem value="categories" className="border-b">
                        <AccordionTrigger className="text-sm font-medium py-2">
                          Categories
                        </AccordionTrigger>
                        <AccordionContent>
                          {categoriesLoading ? (
                            <div className="space-y-2">
                              {[1, 2, 3, 4].map((i) => (
                                <div key={i} className="h-5 bg-slate-200 rounded animate-pulse"></div>
                              ))}
                            </div>
                          ) : (
                            <div className="space-y-2">
                              {categories?.map((category: Category) => (
                                <div key={category.id} className="flex items-center space-x-2">
                                  <Checkbox 
                                    id={`category-${category.slug}`}
                                    checked={selectedCategories.includes(category.slug)}
                                    onCheckedChange={() => handleCategoryChange(category.slug)}
                                  />
                                  <label 
                                    htmlFor={`category-${category.slug}`}
                                    className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                  >
                                    {category.name}
                                  </label>
                                </div>
                              ))}
                            </div>
                          )}
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="price" className="border-b">
                        <AccordionTrigger className="text-sm font-medium py-2">
                          Price Range
                        </AccordionTrigger>
                        <AccordionContent>
                          <div className="space-y-2">
                            <div className="flex items-center space-x-2">
                              <Checkbox id="price-1" />
                              <label 
                                htmlFor="price-1"
                                className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Under KSh 1,000
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="price-2" />
                              <label 
                                htmlFor="price-2"
                                className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                KSh 1,000 - KSh 5,000
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="price-3" />
                              <label 
                                htmlFor="price-3"
                                className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                KSh 5,000 - KSh 10,000
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="price-4" />
                              <label 
                                htmlFor="price-4"
                                className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                KSh 10,000 - KSh 50,000
                              </label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox id="price-5" />
                              <label 
                                htmlFor="price-5"
                                className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                              >
                                Over KSh 50,000
                              </label>
                            </div>
                          </div>
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem value="rating" className="border-b">
                        <AccordionTrigger className="text-sm font-medium py-2">
                          Rating
                        </AccordionTrigger>
                        <AccordionContent>
                          <div className="space-y-2">
                            {[5, 4, 3, 2, 1].map((rating) => (
                              <div key={rating} className="flex items-center space-x-2">
                                <Checkbox id={`rating-${rating}`} />
                                <label 
                                  htmlFor={`rating-${rating}`}
                                  className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center"
                                >
                                  {Array(rating).fill(0).map((_, i) => (
                                    <svg 
                                      key={i}
                                      className="w-4 h-4 text-amber-400 fill-current"
                                      viewBox="0 0 24 24"
                                    >
                                      <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                                    </svg>
                                  ))}
                                  <span className="ml-1">& Up</span>
                                </label>
                              </div>
                            ))}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </CardContent>
                </Card>
              </div>

              {/* Mobile Filters (Slide Down) */}
              <div className={cn(
                "md:hidden fixed inset-0 z-40 bg-white transform transition-transform duration-300 ease-in-out",
                mobileFiltersOpen ? "translate-y-0" : "-translate-y-full"
              )}>
                <div className="p-4 border-b">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold">Filters</h2>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setMobileFiltersOpen(false)}
                    >
                      Close
                    </Button>
                  </div>
                </div>
                <div className="p-4 overflow-y-auto h-[calc(100vh-60px)]">
                  <Accordion type="single" collapsible className="w-full" defaultValue="categories">
                    <AccordionItem value="categories" className="border-b">
                      <AccordionTrigger className="text-sm font-medium py-2">
                        Categories
                      </AccordionTrigger>
                      <AccordionContent>
                        {categoriesLoading ? (
                          <div className="space-y-2">
                            {[1, 2, 3, 4].map((i) => (
                              <div key={i} className="h-5 bg-slate-200 rounded animate-pulse"></div>
                            ))}
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {categories?.map((category: Category) => (
                              <div key={category.id} className="flex items-center space-x-2">
                                <Checkbox 
                                  id={`mobile-category-${category.slug}`}
                                  checked={selectedCategories.includes(category.slug)}
                                  onCheckedChange={() => handleCategoryChange(category.slug)}
                                />
                                <label 
                                  htmlFor={`mobile-category-${category.slug}`}
                                  className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                >
                                  {category.name}
                                </label>
                              </div>
                            ))}
                          </div>
                        )}
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="price" className="border-b">
                      <AccordionTrigger className="text-sm font-medium py-2">
                        Price Range
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Checkbox id="mobile-price-1" />
                            <label 
                              htmlFor="mobile-price-1"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Under KSh 1,000
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="mobile-price-2" />
                            <label 
                              htmlFor="mobile-price-2"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              KSh 1,000 - KSh 5,000
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="mobile-price-3" />
                            <label 
                              htmlFor="mobile-price-3"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              KSh 5,000 - KSh 10,000
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="mobile-price-4" />
                            <label 
                              htmlFor="mobile-price-4"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              KSh 10,000 - KSh 50,000
                            </label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Checkbox id="mobile-price-5" />
                            <label 
                              htmlFor="mobile-price-5"
                              className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              Over KSh 50,000
                            </label>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>

                    <AccordionItem value="rating" className="border-b">
                      <AccordionTrigger className="text-sm font-medium py-2">
                        Rating
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          {[5, 4, 3, 2, 1].map((rating) => (
                            <div key={rating} className="flex items-center space-x-2">
                              <Checkbox id={`mobile-rating-${rating}`} />
                              <label 
                                htmlFor={`mobile-rating-${rating}`}
                                className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center"
                              >
                                {Array(rating).fill(0).map((_, i) => (
                                  <svg 
                                    key={i}
                                    className="w-4 h-4 text-amber-400 fill-current"
                                    viewBox="0 0 24 24"
                                  >
                                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                                  </svg>
                                ))}
                                <span className="ml-1">& Up</span>
                              </label>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>

                  <div className="pt-4 flex gap-2">
                    <Button 
                      className="flex-1"
                      onClick={() => setMobileFiltersOpen(false)}
                    >
                      Apply Filters
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1"
                      onClick={handleClearFilters}
                    >
                      Clear All
                    </Button>
                  </div>
                </div>
              </div>

              {/* Products Grid */}
              <div className="w-full md:w-3/4 lg:w-4/5">
                <div className="mb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <div className="text-sm text-slate-500">
                    Showing {products?.length ? (currentPage - 1) * productsPerPage + 1 : 0} - {Math.min(currentPage * productsPerPage, totalProducts)} of {totalProducts} products
                  </div>
                  <div className="flex items-center">
                    <span className="text-sm mr-2">Sort by:</span>
                    <Select value={sortBy} onValueChange={handleSortChange}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="featured">Featured</SelectItem>
                        <SelectItem value="newest">Newest</SelectItem>
                        <SelectItem value="price-low">Price: Low to High</SelectItem>
                        <SelectItem value="price-high">Price: High to Low</SelectItem>
                        <SelectItem value="rating">Highest Rating</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {productsLoading ? (
                  // Products loading state
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {Array(8).fill(null).map((_, index) => (
                      <div key={index} className="bg-white rounded-lg shadow-sm overflow-hidden">
                        <div className="h-60 bg-slate-200 animate-pulse" />
                        <div className="p-4 space-y-2">
                          <div className="h-3 bg-slate-200 rounded animate-pulse" />
                          <div className="h-5 bg-slate-200 rounded w-3/4 animate-pulse" />
                          <div className="flex space-x-1">
                            {Array(5).fill(null).map((_, i) => (
                              <div key={i} className="h-4 w-4 bg-slate-200 rounded-full animate-pulse" />
                            ))}
                          </div>
                          <div className="flex justify-between items-center pt-2">
                            <div className="h-6 bg-slate-200 rounded w-20 animate-pulse" />
                            <div className="h-8 w-8 bg-slate-200 rounded-lg animate-pulse" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : products?.length === 0 ? (
                  // No products found
                  <div className="bg-white rounded-lg shadow-sm p-8 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 text-slate-400">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.5}
                          d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </div>
                    <h3 className="text-lg font-semibold text-slate-800 mb-2">No products found</h3>
                    <p className="text-slate-600 mb-6">
                      {searchTerm 
                        ? `We couldn't find any products matching "${searchTerm}".` 
                        : "We couldn't find any products matching your criteria."
                      }
                    </p>
                    <Button onClick={handleClearFilters}>Clear Filters</Button>
                  </div>
                ) : (
                  // Products grid
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {currentPageProducts.map((product: Product) => (
                        <ProductCard key={product.id} product={product} />
                      ))}
                    </div>

                    {/* Pagination */}
                    {totalPages > 1 && (
                      <Pagination className="mt-8">
                        <PaginationContent>
                          <PaginationItem>
                            <PaginationPrevious
                              onClick={() => currentPage > 1 && handlePageChange(currentPage - 1)}
                              className={cn(currentPage === 1 && "pointer-events-none opacity-50")}
                            />
                          </PaginationItem>
                          
                          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                            <PaginationItem key={page}>
                              <PaginationLink
                                isActive={currentPage === page}
                                onClick={() => handlePageChange(page)}
                              >
                                {page}
                              </PaginationLink>
                            </PaginationItem>
                          ))}
                          
                          <PaginationItem>
                            <PaginationNext
                              onClick={() => currentPage < totalPages && handlePageChange(currentPage + 1)}
                              className={cn(currentPage === totalPages && "pointer-events-none opacity-50")}
                            />
                          </PaginationItem>
                        </PaginationContent>
                      </Pagination>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
