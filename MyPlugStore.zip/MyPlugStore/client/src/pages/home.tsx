import { Helmet } from "react-helmet";
import HeroSection from "@/components/home/HeroSection";
import CategorySection from "@/components/home/CategorySection";
import FeaturedProducts from "@/components/home/FeaturedProducts";
import BannerSection from "@/components/home/BannerSection";
import TrendingProducts from "@/components/home/TrendingProducts";
import FeaturesSection from "@/components/home/FeaturesSection";
import NewsletterSection from "@/components/home/NewsletterSection";
import TokenSection from "@/components/home/TokenSection";

export default function Home() {
  return (
    <>
      <Helmet>
        <title>THE PLUG - Kenya's Premier Marketplace | Shop with PLUG Token</title>
        <meta name="description" content="Discover quality products from trusted sellers across Kenya. THE PLUG offers fast delivery, secure payments, and exclusive benefits with our native token." />
        <meta property="og:title" content="THE PLUG - Kenya's Premier Marketplace | Shop with PLUG Token" />
        <meta property="og:description" content="Discover quality products from trusted sellers across Kenya. THE PLUG offers fast delivery, secure payments, and exclusive benefits with our native token." />
        <meta property="og:type" content="website" />
      </Helmet>
      <HeroSection />
      <CategorySection />
      <FeaturedProducts />
      <BannerSection />
      <TrendingProducts />
      <TokenSection />
      <FeaturesSection />
      <NewsletterSection />
    </>
  );
}
