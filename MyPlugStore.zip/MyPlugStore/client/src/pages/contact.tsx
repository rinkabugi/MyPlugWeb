import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Helmet } from "react-helmet";
import { Phone, Mail, MapPin } from "lucide-react";

// Form validation schema
const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters."
  }),
  email: z.string().email({
    message: "Please enter a valid email address."
  }),
  phone: z.string().min(10, {
    message: "Please enter a valid phone number."
  }).optional(),
  message: z.string().min(10, {
    message: "Message must be at least 10 characters."
  }),
});

type FormData = z.infer<typeof formSchema>;

export default function Contact() {
  const { toast } = useToast();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: ""
    }
  });
  
  const onSubmit = (data: FormData) => {
    // In a real app, this would send the data to the server
    console.log(data);
    
    toast({
      title: "Message Sent",
      description: "Thank you for contacting us. We'll get back to you soon.",
    });
    
    form.reset();
  };
  
  return (
    <>
      <Helmet>
        <title>Contact Us | THE PLUG</title>
        <meta name="description" content="Get in touch with THE PLUG - Kenya's premier ecommerce platform. We're here to help with your shopping needs and answer any questions about our products or services." />
      </Helmet>
      
      <main className="container mx-auto px-4 py-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-8 text-center">
          <span className="text-secondary">Contact</span> Us
        </h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="space-y-8">
            <p className="text-lg">
              We're here to help with any questions you may have about our products or services. 
              Fill out the form and our team will get back to you as soon as possible.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <Phone className="text-secondary h-6 w-6 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg">Phone</h3>
                  <p>+254 700 123 456</p>
                  <p>Mon-Fri, 8am - 6pm EAT</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <Mail className="text-secondary h-6 w-6 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg">Email</h3>
                  <p>support@theplug.co.ke</p>
                  <p>We aim to respond within 24 hours</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <MapPin className="text-secondary h-6 w-6 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg">Location</h3>
                  <p>Nairobi, Kenya</p>
                  <p>Westlands Business Center, 2nd Floor</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-900 p-6 rounded-lg border border-gray-800">
              <h3 className="font-semibold text-lg mb-4">Payment Methods</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <div className="bg-white p-1 rounded">
                    <img src="/assets/mpesa-logo.png" alt="M-Pesa" className="h-8" />
                  </div>
                  <span>M-Pesa</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="bg-white p-1 rounded">
                    <img src="/assets/visa-logo.png" alt="Visa" className="h-8" />
                  </div>
                  <span>Visa</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="bg-white p-1 rounded">
                    <img src="/assets/mastercard-logo.png" alt="Mastercard" className="h-8" />
                  </div>
                  <span>Mastercard</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="bg-white p-1 rounded">
                    <img src="/assets/plug-logo.jpg" alt="PLUG Token" className="h-8 w-8 rounded-full" />
                  </div>
                  <span>PLUG Token</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-900 p-6 rounded-lg border border-gray-800">
            <h2 className="text-xl font-semibold mb-6">Send Us a Message</h2>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Your Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="your@email.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="+254 7XX XXX XXX" {...field} />
                      </FormControl>
                      <FormDescription>
                        Format: +254 followed by your 9-digit number
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="How can we help you?" 
                          className="min-h-[120px]" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button type="submit" className="w-full bg-secondary hover:bg-secondary/90">
                  Send Message
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </main>
    </>
  );
}