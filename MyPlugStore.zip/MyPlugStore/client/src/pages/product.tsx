import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { useCart } from "@/hooks/useCart";
import { Button } from "@/components/ui/button";
import { Helmet } from "react-helmet";
import { 
  ChevronRight, 
  Minus, 
  Plus, 
  Star, 
  StarHalf,
  ShoppingCart,
  Heart,
  Share2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function Product() {
  const { toast } = useToast();
  const { slug } = useParams();
  const { addToCart, openCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [isWishlistActive, setIsWishlistActive] = useState(false);

  const { data: product, isLoading, error } = useQuery({
    queryKey: [`/api/products/${slug}`],
  });

  const handleAddToCart = () => {
    if (!product) return;
    
    addToCart(product.id, quantity);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart`,
    });
    openCart();
  };

  const handleQuantityChange = (value: number) => {
    setQuantity(Math.max(1, value));
  };

  const toggleWishlist = () => {
    setIsWishlistActive(!isWishlistActive);
    if (product) {
      toast({
        title: isWishlistActive ? "Removed from wishlist" : "Added to wishlist",
        description: isWishlistActive ? `${product.name} was removed from your wishlist` : `${product.name} was added to your wishlist`,
      });
    }
  };

  const renderRatingStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const stars = [];

    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="fill-amber-400 text-amber-400" />);
    }

    // Add half star if needed
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="fill-amber-400 text-amber-400" />);
    }

    // Add empty stars
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-amber-400" />);
    }

    return stars;
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="w-full md:w-1/2 bg-slate-200 h-96 animate-pulse rounded-lg"></div>
          <div className="w-full md:w-1/2 space-y-4">
            <div className="h-4 bg-slate-200 rounded w-1/3 animate-pulse"></div>
            <div className="h-8 bg-slate-200 rounded w-3/4 animate-pulse"></div>
            <div className="h-4 bg-slate-200 rounded w-1/4 animate-pulse"></div>
            <div className="h-6 bg-slate-200 rounded w-1/3 animate-pulse"></div>
            <div className="h-24 bg-slate-200 rounded animate-pulse"></div>
            <div className="h-10 bg-slate-200 rounded animate-pulse"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-slate-800 mb-4">Product Not Found</h1>
        <p className="text-slate-600 mb-6">Sorry, the requested product could not be found.</p>
        <Button asChild>
          <Link href="/products">Back to Products</Link>
        </Button>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{product.name} - MY PLUG</title>
        <meta name="description" content={product.description} />
        <meta property="og:title" content={`${product.name} - MY PLUG`} />
        <meta property="og:description" content={product.description} />
        <meta property="og:image" content={product.imageUrl} />
        <meta property="og:type" content="product" />
      </Helmet>

      <div className="bg-white">
        <div className="container mx-auto px-4 py-8">
          {/* Breadcrumb */}
          <nav className="flex items-center text-sm text-slate-500 mb-6">
            <Link href="/">
              <a className="hover:text-primary">Home</a>
            </Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <Link href="/products">
              <a className="hover:text-primary">Products</a>
            </Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <Link href={`/products?category=${product.categoryId}`}>
              <a className="hover:text-primary">{product.categoryName}</a>
            </Link>
            <ChevronRight className="h-4 w-4 mx-2" />
            <span className="text-slate-800 font-medium truncate">{product.name}</span>
          </nav>

          <div className="flex flex-col md:flex-row gap-8">
            {/* Product Image */}
            <div className="w-full md:w-1/2">
              <div className="bg-white rounded-lg overflow-hidden border border-slate-200">
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="w-full h-auto object-cover aspect-square"
                />
              </div>
            </div>

            {/* Product Details */}
            <div className="w-full md:w-1/2">
              <div className="mb-2 flex items-center">
                <span className="text-sm bg-slate-100 text-slate-700 px-2 py-1 rounded">
                  {product.categoryName}
                </span>
                {product.badge && (
                  <span className="ml-2 text-sm bg-secondary text-white px-2 py-1 rounded">
                    {product.badge}
                  </span>
                )}
              </div>

              <h1 className="text-3xl font-bold text-slate-800 mb-2">{product.name}</h1>

              <div className="flex items-center mb-4">
                <div className="flex">
                  {renderRatingStars(Number(product.rating))}
                </div>
                <span className="text-sm text-slate-500 ml-2">
                  ({product.reviews} reviews)
                </span>
              </div>

              <div className="mb-6">
                <span className="text-3xl font-bold text-slate-800">
                  KSh {Number(product.price).toLocaleString()}
                </span>
                {product.comparePrice && (
                  <span className="text-lg text-slate-500 line-through ml-2">
                    KSh {Number(product.comparePrice).toLocaleString()}
                  </span>
                )}
              </div>

              <div className="mb-6">
                <p className="text-slate-600">{product.description}</p>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Quantity
                </label>
                <div className="flex items-center">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-10 w-10"
                    onClick={() => handleQuantityChange(quantity - 1)}
                    disabled={quantity <= 1}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                    className="h-10 w-16 mx-2 text-center border border-slate-300 rounded"
                    min="1"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-10 w-10"
                    onClick={() => handleQuantityChange(quantity + 1)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="flex flex-wrap gap-4">
                <Button 
                  className="flex-1 md:flex-none md:w-auto" 
                  size="lg"
                  onClick={handleAddToCart}
                >
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  Add to Cart
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  className={cn(
                    "flex-1 md:flex-none md:w-auto",
                    isWishlistActive && "bg-red-50 text-red-500 border-red-200"
                  )}
                  onClick={toggleWishlist}
                >
                  <Heart className={cn("mr-2 h-5 w-5", isWishlistActive && "fill-red-500")} />
                  {isWishlistActive ? "Saved" : "Save"}
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-12 w-12 border border-slate-200"
                >
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>

              <div className="mt-8 border-t border-slate-200 pt-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <div className="rounded-full bg-primary-100 p-2 text-primary">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="1" y="3" width="22" height="18" rx="2" ry="2"></rect>
                        <line x1="10" y1="9" x2="14" y2="9"></line>
                        <line x1="12" y1="13" x2="12" y2="13"></line>
                        <line x1="12" y1="17" x2="12" y2="17"></line>
                      </svg>
                    </div>
                    <span className="ml-2 text-sm">Secure Payment</span>
                  </div>
                  <div className="flex items-center">
                    <div className="rounded-full bg-primary-100 p-2 text-primary">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                        <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                      </svg>
                    </div>
                    <span className="ml-2 text-sm">Fast Shipping</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
