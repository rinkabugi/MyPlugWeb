import { useState } from "react";
import { Helmet } from "react-helmet";
import { useCart } from "@/hooks/useCart";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { ArrowLeft, CreditCard, Loader2, MapPin, Truck } from "lucide-react";

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { cart, cartEmpty } = useCart();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deliveryMethod, setDeliveryMethod] = useState("standard");
  const [paymentMethod, setPaymentMethod] = useState("mpesa");

  if (!cart || cart.items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="max-w-md mx-auto">
          <div className="mb-6 text-slate-400">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-20 w-20 mx-auto"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
              />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-4">Your cart is empty</h1>
          <p className="text-slate-600 mb-6">
            There are no items in your cart. Add some products to proceed with checkout.
          </p>
          <Button asChild>
            <a href="/products">Continue Shopping</a>
          </Button>
        </div>
      </div>
    );
  }

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    mpesaNumber: "",
  });

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      if (paymentMethod === "mpesa") {
        // Validate M-Pesa phone number
        if (!formData.mpesaNumber) {
          toast({
            title: "M-Pesa Number Required",
            description: "Please enter your M-Pesa phone number.",
            variant: "destructive",
          });
          setIsSubmitting(false);
          return;
        }

        // Calculate total amount
        const total = cart?.total || 0;
        const orderReference = `ORDER-${Date.now()}`;

        // Make M-Pesa STK Push request
        const response = await fetch('/api/mpesa/stkpush', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            phoneNumber: formData.mpesaNumber,
            amount: total,
            accountReference: orderReference,
            transactionDesc: `Payment for THE PLUG Order ${orderReference}`
          }),
        });

        const result = await response.json();

        if (result.success) {
          toast({
            title: "Payment Request Sent!",
            description: "Check your phone for the M-Pesa payment prompt. Complete the payment to finish your order.",
          });

          // Wait for user to complete payment (in production, you'd use webhooks)
          setTimeout(() => {
            toast({
              title: "Order Completed!",
              description: "Thank you for your purchase. Your order is being processed.",
            });
            cartEmpty();
            setLocation("/");
          }, 10000); // 10 seconds to simulate payment completion
        } else {
          toast({
            title: "Payment Failed",
            description: result.message || "Failed to initiate M-Pesa payment. Please try again.",
            variant: "destructive",
          });
        }
      } else {
        // Handle other payment methods (Card, PLUG Token, Cash on Delivery)
        toast({
          title: "Payment Method Not Available",
          description: "This payment method is coming soon. Please use M-Pesa for now.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast({
        title: "Payment Error",
        description: "Something went wrong processing your payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Checkout - THE PLUG</title>
        <meta name="description" content="Complete your purchase with our secure checkout process, including M-Pesa and PLUG token payment options." />
        <meta property="og:title" content="Checkout - THE PLUG" />
        <meta property="og:description" content="Complete your purchase with our secure checkout process, including M-Pesa and PLUG token payment options." />
        <meta property="og:type" content="website" />
      </Helmet>

      <div className="bg-white">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <button 
              onClick={() => setLocation("/products")}
              className="inline-flex items-center text-primary hover:text-primary-600 font-medium"
            >
              <ArrowLeft className="h-4 w-4 mr-1" />
              Continue Shopping
            </button>
          </div>

          <h1 className="text-2xl font-bold text-slate-800 mb-6">Checkout</h1>

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Checkout Form */}
            <div className="w-full lg:w-2/3">
              <form onSubmit={handleSubmitOrder}>
                <div className="space-y-6">
                  {/* Contact Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Contact Information</CardTitle>
                      <CardDescription>
                        We'll use this information to keep you updated about your order.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="firstName">First Name</Label>
                          <Input 
                            id="firstName" 
                            value={formData.firstName}
                            onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                            required 
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="lastName">Last Name</Label>
                          <Input 
                            id="lastName" 
                            value={formData.lastName}
                            onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                            required 
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <Input 
                          id="email" 
                          type="email" 
                          value={formData.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          required 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input 
                          id="phone" 
                          type="tel" 
                          value={formData.phone}
                          onChange={(e) => setFormData({...formData, phone: e.target.value})}
                          required 
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Shipping Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Shipping Information</CardTitle>
                      <CardDescription>
                        Enter your address where you want your order to be delivered.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="address">Street Address</Label>
                        <Input id="address" required />
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="city">City</Label>
                          <Input id="city" required />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="region">County/Region</Label>
                          <Select defaultValue="nairobi">
                            <SelectTrigger>
                              <SelectValue placeholder="Select county" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="nairobi">Nairobi</SelectItem>
                              <SelectItem value="mombasa">Mombasa</SelectItem>
                              <SelectItem value="kisumu">Kisumu</SelectItem>
                              <SelectItem value="nakuru">Nakuru</SelectItem>
                              <SelectItem value="eldoret">Eldoret</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="postalCode">Postal Code</Label>
                          <Input id="postalCode" required />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="country">Country</Label>
                          <Select defaultValue="kenya" disabled>
                            <SelectTrigger>
                              <SelectValue placeholder="Select country" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="kenya">Kenya</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="deliveryInstructions">Delivery Instructions (Optional)</Label>
                        <Input id="deliveryInstructions" placeholder="E.g., Leave at the reception, call before delivery" />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Delivery Options */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Delivery Method</CardTitle>
                      <CardDescription>
                        Choose how you want your order to be delivered.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <RadioGroup 
                        value={deliveryMethod} 
                        onValueChange={setDeliveryMethod}
                        className="space-y-3"
                      >
                        <div className={cn(
                          "flex items-start space-x-3 space-y-0 rounded-md border p-4 cursor-pointer",
                          deliveryMethod === "standard" && "border-primary"
                        )}>
                          <RadioGroupItem value="standard" id="delivery-standard" className="mt-1" />
                          <div className="flex-1">
                            <Label htmlFor="delivery-standard" className="font-medium flex items-center cursor-pointer">
                              <Truck className="mr-2 h-5 w-5" />
                              Standard Delivery (2-5 days)
                            </Label>
                            <p className="text-sm text-slate-500 mt-1">
                              KSh 400 - Free for orders above KSh 10,000
                            </p>
                          </div>
                          <div className="text-right font-medium">
                            KSh 400
                          </div>
                        </div>
                        <div className={cn(
                          "flex items-start space-x-3 space-y-0 rounded-md border p-4 cursor-pointer",
                          deliveryMethod === "express" && "border-primary"
                        )}>
                          <RadioGroupItem value="express" id="delivery-express" className="mt-1" />
                          <div className="flex-1">
                            <Label htmlFor="delivery-express" className="font-medium flex items-center cursor-pointer">
                              <Truck className="mr-2 h-5 w-5" />
                              Express Delivery (1-2 days)
                            </Label>
                            <p className="text-sm text-slate-500 mt-1">
                              Fast delivery service within Nairobi and major towns
                            </p>
                          </div>
                          <div className="text-right font-medium">
                            KSh 800
                          </div>
                        </div>
                        <div className={cn(
                          "flex items-start space-x-3 space-y-0 rounded-md border p-4 cursor-pointer",
                          deliveryMethod === "pickup" && "border-primary"
                        )}>
                          <RadioGroupItem value="pickup" id="delivery-pickup" className="mt-1" />
                          <div className="flex-1">
                            <Label htmlFor="delivery-pickup" className="font-medium flex items-center cursor-pointer">
                              <MapPin className="mr-2 h-5 w-5" />
                              Pickup from Store
                            </Label>
                            <p className="text-sm text-slate-500 mt-1">
                              Collect from our shop at Westlands, Nairobi
                            </p>
                          </div>
                          <div className="text-right font-medium">
                            Free
                          </div>
                        </div>
                      </RadioGroup>
                    </CardContent>
                  </Card>

                  {/* Payment Method */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Payment Method</CardTitle>
                      <CardDescription>
                        Choose a secure payment method to complete your order.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Tabs defaultValue="mpesa" value={paymentMethod} onValueChange={setPaymentMethod}>
                        <TabsList className="grid grid-cols-4 mb-4">
                          <TabsTrigger value="mpesa" className="flex items-center justify-center">
                            <div className="flex items-center">
                              <span className="font-bold text-green-600 mr-1">M-</span>
                              <span className="font-bold">PESA</span>
                            </div>
                          </TabsTrigger>
                          <TabsTrigger value="card">
                            <CreditCard className="h-4 w-4 mr-1" />
                            Card
                          </TabsTrigger>
                          <TabsTrigger value="plug">
                            <img src="/assets/plug-logo.jpg" alt="PLUG" className="h-4 w-4 mr-1 rounded-full" />
                            PLUG Token
                          </TabsTrigger>
                          <TabsTrigger value="cod">Cash on Delivery</TabsTrigger>
                        </TabsList>
                        
                        <TabsContent value="mpesa" className="space-y-4">
                          <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-4">
                            <div className="flex items-center">
                              <div className="bg-white p-1 rounded mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="20" viewBox="0 0 68 34">
                                  <g fill="none" fillRule="evenodd">
                                    <path fill="#D9E021" d="M67.952 24.936c0 4.998-4.05 9.048-9.05 9.048H9.048C4.05 33.984 0 29.934 0 24.936V9.048C0 4.05 4.05 0 9.048 0h49.856c4.998 0 9.048 4.05 9.048 9.048v15.888z"/>
                                    <path fill="#49B749" d="M46.876 6.499H35.328c-2.32 0-8.77.006-12.557 7.89-1.759 3.689-2.981 8.053-3.445 15.647h6.016c0-.232.046-.437.138-.638.277-.63.883-1.024 1.541-1.024h19.386c1.02 0 1.848-.828 1.848-1.848l.23-18.183c0-1.02-.826-1.844-1.844-1.844h.235z"/>
                                    <path fill="#000" d="M13.326 24.856h1.324v3.982h1.716v1.142h-3.04zM18.93 24.856v5.124h-1.324v-5.124zM21.202 24.856l1 3.052h.022l.984-3.052h1.826v5.124h-1.324v-3.124h-.022l-1.078 3.124h-.812l-1.078-3.098h-.022v3.098h-1.322v-5.124zM29.09 24.856v3.072c0 .538.294.866.774.866.474 0 .772-.328.772-.866v-3.072h1.324v3.03c0 1.3-.742 2.184-2.106 2.184-1.366 0-2.088-.882-2.088-2.198v-3.016zM35.416 24.856v3.072c0 .538.294.866.774.866.474 0 .772-.328.772-.866v-3.072h1.324v3.03c0 1.3-.742 2.184-2.106 2.184-1.366 0-2.088-.882-2.088-2.198v-3.016zM40.032 24.856h1.324v5.124h-1.324zM43.218 24.856h2.186c1.286 0 1.9.648 1.9 1.68 0 .99-.6 1.534-1.714 1.534h-.846v1.91h-1.526v-5.124zm1.526 2.126h.392c.418 0 .642-.204.642-.48 0-.274-.224-.49-.642-.49h-.392v.97zM47.762 24.856h1.764l1.694 3.222h.02v-3.222h1.324v5.124h-1.688l-1.772-3.34h-.02v3.34h-1.322z"/>
                                  </g>
                                </svg>
                              </div>
                              <div>
                                <p className="font-semibold">Pay with M-PESA</p>
                                <p className="text-xs text-slate-600">Fast, secure, and convenient mobile payment</p>
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="mpesa-number">M-PESA Phone Number</Label>
                            <Input 
                              id="mpesa-number" 
                              type="tel" 
                              placeholder="e.g., 07XX XXX XXX"
                              value={formData.mpesaNumber}
                              onChange={(e) => setFormData({...formData, mpesaNumber: e.target.value})}
                              required={paymentMethod === "mpesa"}
                              data-testid="input-mpesa-number"
                            />
                            <p className="text-xs text-slate-500">
                              You'll receive an STK push prompt on your phone to complete the payment.
                            </p>
                          </div>
                          
                          <div className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                            <span className="text-sm">Payment steps:</span>
                            <ol className="text-xs text-slate-600 list-decimal ml-4 space-y-1">
                              <li>Enter your M-PESA registered phone number</li>
                              <li>Click "Place Order" below</li>
                              <li>Check your phone for M-PESA PIN prompt</li>
                              <li>Enter your M-PESA PIN to complete payment</li>
                            </ol>
                          </div>
                        </TabsContent>
                        
                        <TabsContent value="plug" className="space-y-4">
                          <div className="bg-black border border-secondary rounded-md p-4 mb-4">
                            <div className="flex items-center">
                              <div className="bg-white p-1 rounded-full mr-3">
                                <img src="/assets/plug-logo.jpg" alt="PLUG Token" className="h-8 w-8 rounded-full" />
                              </div>
                              <div>
                                <p className="font-semibold text-white">Pay with PLUG Token</p>
                                <p className="text-xs text-gray-400">Get 15% discount when paying with PLUG tokens</p>
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <Label htmlFor="wallet-address">Your Wallet Address</Label>
                            <Input 
                              id="wallet-address" 
                              placeholder="e.g., 5YcZN..."
                              required={paymentMethod === "plug"}
                            />
                            <p className="text-xs text-slate-500">
                              Enter your Solana wallet address that holds PLUG tokens
                            </p>
                          </div>
                          
                          <div className="flex flex-col space-y-2 bg-gray-50 p-3 rounded-md">
                            <span className="text-sm font-medium">Token information:</span>
                            <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                              <div>
                                <span className="font-medium">Contract:</span>
                                <p className="font-mono text-xs break-all">6nBZsNXjc2BwfPpJeqiQkYHbgQKYcT5MG1oQeT7Hpump</p>
                              </div>
                              <div>
                                <span className="font-medium">Network:</span>
                                <p>Solana</p>
                              </div>
                              <div>
                                <span className="font-medium">Current Price:</span>
                                <p className="text-secondary">$0.023 USD</p>
                              </div>
                              <div>
                                <span className="font-medium">Discount:</span>
                                <p className="text-green-600">15%</p>
                              </div>
                            </div>
                            
                            <div className="flex justify-between items-center mt-2 pt-2 border-t border-gray-200">
                              <span className="text-xs">Don't have PLUG tokens?</span>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => window.open("https://pump.fun/token/6nBZsNXjc2BwfPpJeqiQkYHbgQKYcT5MG1oQeT7Hpump", "_blank")}
                                className="text-xs"
                              >
                                Buy on pump.fun
                              </Button>
                            </div>
                          </div>
                        </TabsContent>
                        
                        <TabsContent value="card" className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="card-number">Card Number</Label>
                            <Input 
                              id="card-number" 
                              placeholder="XXXX XXXX XXXX XXXX"
                              required={paymentMethod === "card"}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="expiry">Expiry Date</Label>
                              <Input 
                                id="expiry" 
                                placeholder="MM/YY"
                                required={paymentMethod === "card"}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="cvc">CVC</Label>
                              <Input 
                                id="cvc" 
                                placeholder="XXX"
                                required={paymentMethod === "card"}
                              />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="name-on-card">Name on Card</Label>
                            <Input 
                              id="name-on-card"
                              required={paymentMethod === "card"}
                            />
                          </div>
                        </TabsContent>
                        <TabsContent value="cod" className="space-y-4">
                          <div className="rounded-md bg-slate-50 p-4">
                            <div className="flex">
                              <div className="flex-shrink-0">
                                <svg className="h-5 w-5 text-slate-400" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z" clipRule="evenodd" />
                                </svg>
                              </div>
                              <div className="ml-3">
                                <p className="text-sm text-slate-700">
                                  You will pay for your order when it's delivered to your address.
                                  <br />
                                  <span className="font-medium">Note:</span> Cash on delivery is only available in select areas.
                                </p>
                              </div>
                            </div>
                          </div>
                        </TabsContent>
                        
                        <TabsContent value="cod" className="space-y-4">
                          <div className="bg-gray-50 border border-gray-200 rounded-md p-4 mb-4">
                            <div className="flex items-center">
                              <div className="mr-3 bg-gray-200 rounded-full p-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                  <rect width="16" height="12" x="4" y="6" rx="2"/>
                                  <circle cx="12" cy="12" r="3"/>
                                  <path d="M8 10V8a4 4 0 0 1 8 0v2"/>
                                </svg>
                              </div>
                              <div>
                                <p className="font-semibold">Pay on Delivery</p>
                                <p className="text-xs text-gray-600">Pay with cash or M-Pesa when your order arrives</p>
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="cod-notes">Delivery Notes (Optional)</Label>
                              <Input 
                                id="cod-notes" 
                                placeholder="Special instructions for delivery"
                              />
                            </div>
                            
                            <div className="flex flex-col space-y-2 bg-gray-50 p-3 rounded-md">
                              <span className="text-sm font-medium">Important notes about Cash on Delivery:</span>
                              <ul className="text-xs text-slate-600 list-disc ml-4 space-y-1">
                                <li>Available in Nairobi and select counties only</li>
                                <li>Have the exact amount ready, our delivery agents don't carry change</li>
                                <li>M-Pesa payment to delivery agent is also accepted</li>
                                <li>You will receive a call before delivery</li>
                              </ul>
                            </div>
                          </div>
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  </Card>

                  {/* Submit Order Button (Mobile) */}
                  <div className="lg:hidden">
                    <Button 
                      type="submit" 
                      className="w-full" 
                      size="lg"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>Place Order - KSh {cart.total.toLocaleString()}</>
                      )}
                    </Button>
                  </div>
                </div>
              </form>
            </div>

            {/* Order Summary */}
            <div className="w-full lg:w-1/3">
              <div className="sticky top-20">
                <Card>
                  <CardHeader>
                    <CardTitle>Order Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="max-h-96 overflow-y-auto space-y-4 scrollbar-hide">
                      {cart.items.map((item) => (
                        <div key={item.id} className="flex items-start border-b border-slate-200 pb-4">
                          <img 
                            src={item.imageUrl} 
                            alt={item.name} 
                            className="w-16 h-16 object-cover rounded mr-3" 
                          />
                          <div className="flex-1">
                            <h4 className="text-sm font-medium text-slate-800 line-clamp-2">{item.name}</h4>
                            <p className="text-xs text-slate-500">Qty: {item.quantity}</p>
                            <div className="mt-1 font-medium">
                              KSh {(item.price * item.quantity).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-2 pt-4">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600">Subtotal</span>
                        <span className="font-medium">KSh {cart.subtotal.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600">Shipping</span>
                        <span className="font-medium">KSh {cart.shipping.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-600">Tax</span>
                        <span className="font-medium">KSh {cart.tax.toLocaleString()}</span>
                      </div>
                      <div className="pt-2 border-t border-slate-200 flex justify-between">
                        <span className="font-semibold text-slate-800">Total</span>
                        <span className="font-bold text-slate-800">KSh {cart.total.toLocaleString()}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    {/* Submit Order Button (Desktop) */}
                    <Button 
                      type="submit" 
                      className="w-full hidden lg:flex" 
                      size="lg"
                      disabled={isSubmitting}
                      onClick={handleSubmitOrder}
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>Place Order</>
                      )}
                    </Button>
                  </CardFooter>
                </Card>

                <div className="mt-4 bg-slate-50 rounded-lg p-4">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <svg className="h-5 w-5 text-slate-400" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-slate-600">
                        Need help with your order? Contact our customer support team at <span className="font-medium">support@myplug.co.ke</span> or call <span className="font-medium">+254 700 000 000</span>.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
