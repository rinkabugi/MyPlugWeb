import React, { createContext, useState, useEffect, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Cart } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface CartContextType {
  cart: Cart | null;
  isCartOpen: boolean;
  toggleCart: () => void;
  closeCart: () => void;
  openCart: () => void;
  addToCart: (productId: number, quantity: number) => void;
  updateCartItemQuantity: (itemId: number, quantity: number) => void;
  removeCartItem: (itemId: number) => void;
  cartEmpty: () => void;
  cartItemsCount: number;
  isLoading: boolean;
}

export const CartContext = createContext<CartContextType>({
  cart: null,
  isCartOpen: false,
  toggleCart: () => {},
  closeCart: () => {},
  openCart: () => {},
  addToCart: () => {},
  updateCartItemQuantity: () => {},
  removeCartItem: () => {},
  cartEmpty: () => {},
  cartItemsCount: 0,
  isLoading: false,
});

interface CartProviderProps {
  children: React.ReactNode;
}

const CART_ID_KEY = "my_plug_cart_id";

export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const { toast } = useToast();
  const [cart, setCart] = useState<Cart | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [cartId, setCartId] = useState<string | null>(null);

  // Calculate cart items count
  const cartItemsCount = cart?.items.reduce((acc, item) => acc + item.quantity, 0) || 0;

  // Toggle cart drawer
  const toggleCart = useCallback(() => {
    setIsCartOpen((prev) => !prev);
  }, []);

  const closeCart = useCallback(() => {
    setIsCartOpen(false);
  }, []);

  const openCart = useCallback(() => {
    setIsCartOpen(true);
  }, []);

  // Create cart mutation
  const createCartMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/cart", undefined);
      return response.json();
    },
    onSuccess: (data: Cart) => {
      setCart(data);
      setCartId(data.id);
      localStorage.setItem(CART_ID_KEY, data.id);
      setIsLoading(false);
    },
    onError: (error) => {
      console.error("Failed to create cart:", error);
      toast({
        title: "Error",
        description: "Failed to create shopping cart. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    },
  });

  // Get cart mutation
  const getCartMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("GET", `/api/cart/${id}`, undefined);
      if (!response.ok) {
        throw new Error(`Cart not found: ${response.status}`);
      }
      return response.json();
    },
    onSuccess: (data: Cart) => {
      setCart(data);
      setIsLoading(false);
    },
    onError: (error) => {
      console.log("Cart not found, creating new cart:", error.message);
      // If cart not found, clean up and create a new one
      localStorage.removeItem(CART_ID_KEY);
      setCartId(null);
      createCartMutation.mutate();
    },
  });

  // Add to cart mutation
  const addToCartMutation = useMutation({
    mutationFn: async ({ id, productId, quantity }: { id: string; productId: number; quantity: number }) => {
      const response = await apiRequest("POST", `/api/cart/${id}/items`, { productId, quantity });
      return response.json();
    },
    onSuccess: (data: Cart) => {
      setCart(data);
    },
    onError: (error) => {
      console.error("Failed to add item to cart:", error);
      toast({
        title: "Error",
        description: "Failed to add item to cart. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update cart item mutation
  const updateCartItemMutation = useMutation({
    mutationFn: async ({ id, itemId, quantity }: { id: string; itemId: number; quantity: number }) => {
      const response = await apiRequest("PUT", `/api/cart/${id}/items/${itemId}`, { quantity });
      return response.json();
    },
    onSuccess: (data: Cart) => {
      setCart(data);
    },
    onError: (error) => {
      console.error("Failed to update cart item:", error);
      toast({
        title: "Error",
        description: "Failed to update item quantity. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Remove cart item mutation
  const removeCartItemMutation = useMutation({
    mutationFn: async ({ id, itemId }: { id: string; itemId: number }) => {
      const response = await apiRequest("DELETE", `/api/cart/${id}/items/${itemId}`, undefined);
      return response.json();
    },
    onSuccess: (data: Cart) => {
      setCart(data);
    },
    onError: (error) => {
      console.error("Failed to remove cart item:", error);
      toast({
        title: "Error",
        description: "Failed to remove item from cart. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Initialize cart
  useEffect(() => {
    const storedCartId = localStorage.getItem(CART_ID_KEY);
    
    if (storedCartId) {
      setCartId(storedCartId);
      getCartMutation.mutate(storedCartId);
    } else {
      createCartMutation.mutate();
    }
  }, []);

  // Add to cart handler
  const addToCart = useCallback((productId: number, quantity: number) => {
    if (!cartId) return;
    
    addToCartMutation.mutate({ id: cartId, productId, quantity });
  }, [cartId]);

  // Update cart item quantity handler
  const updateCartItemQuantity = useCallback((itemId: number, quantity: number) => {
    if (!cartId) return;
    
    updateCartItemMutation.mutate({ id: cartId, itemId, quantity });
  }, [cartId]);

  // Remove cart item handler
  const removeCartItem = useCallback((itemId: number) => {
    if (!cartId) return;
    
    removeCartItemMutation.mutate({ id: cartId, itemId });
  }, [cartId]);

  // Empty cart handler
  const cartEmpty = useCallback(() => {
    if (!cart || !cartId) return;
    
    // Remove all items one by one
    cart.items.forEach(item => {
      removeCartItemMutation.mutate({ id: cartId, itemId: item.id });
    });
  }, [cart, cartId]);

  return (
    <CartContext.Provider
      value={{
        cart,
        isCartOpen,
        toggleCart,
        closeCart,
        openCart,
        addToCart,
        updateCartItemQuantity,
        removeCartItem,
        cartEmpty,
        cartItemsCount,
        isLoading,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
