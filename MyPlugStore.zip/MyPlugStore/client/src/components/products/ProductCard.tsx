import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/useCart";
import { cn } from "@/lib/utils";
import { Heart, ShoppingCart, Star, StarHalf } from "lucide-react";
import { Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface ProductCardProps {
  product: Product & { categoryName?: string };
}

export default function ProductCard({ product }: ProductCardProps) {
  const { toast } = useToast();
  const { addToCart } = useCart();
  const [isWishlistActive, setIsWishlistActive] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  const toggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsWishlistActive(!isWishlistActive);
    toast({
      title: isWishlistActive ? "Removed from wishlist" : "Added to wishlist",
      description: isWishlistActive ? `${product.name} was removed from your wishlist` : `${product.name} was added to your wishlist`,
    });
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsAdding(true);
    
    // Simulate a short delay for better UX
    setTimeout(() => {
      addToCart(product.id, 1);
      setIsAdding(false);
      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart`,
      });
    }, 300);
  };

  const renderRatingStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const stars = [];

    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="fill-amber-400 text-amber-400" />);
    }

    // Add half star if needed
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="fill-amber-400 text-amber-400" />);
    }

    // Add empty stars
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-amber-400" />);
    }

    return stars;
  };

  return (
    <Link 
      href={`/products/${product.slug}`}
      className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden h-full flex flex-col"
    >
        <div className="relative">
          <img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-60 object-cover" 
          />
          <div className="absolute top-2 right-2">
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-slate-400 hover:text-primary shadow-sm"
              onClick={toggleWishlist}
            >
              <Heart className={cn(isWishlistActive && "fill-red-500 text-red-500")} />
            </Button>
          </div>
          {product.badge && (
            <div className="absolute top-2 left-2 bg-secondary text-white text-xs font-bold px-2 py-1 rounded">
              {product.badge}
            </div>
          )}
        </div>
        <div className="p-4 flex-grow flex flex-col">
          <div className="text-xs text-slate-500 mb-1">{product.categoryName || 'Uncategorized'}</div>
          <h3 className="font-medium text-slate-800 mb-2 line-clamp-2">{product.name}</h3>
          <div className="flex items-center mb-2">
            <div className="flex text-amber-400">
              {renderRatingStars(Number(product.rating))}
            </div>
            <span className="text-xs text-slate-500 ml-1">({product.reviews})</span>
          </div>
          <div className="flex items-center justify-between mt-auto">
            <div>
              <span className="font-bold text-lg text-slate-800">
                KSh {Number(product.price).toLocaleString()}
              </span>
              {product.comparePrice && (
                <span className="text-sm text-slate-500 line-through ml-2">
                  KSh {Number(product.comparePrice).toLocaleString()}
                </span>
              )}
            </div>
            <Button
              size="icon"
              className="bg-primary hover:bg-primary-700 text-white"
              onClick={handleAddToCart}
              disabled={isAdding}
            >
              <ShoppingCart className={cn("h-4 w-4", isAdding && "animate-spin")} />
            </Button>
          </div>
        </div>
    </Link>
  );
}
