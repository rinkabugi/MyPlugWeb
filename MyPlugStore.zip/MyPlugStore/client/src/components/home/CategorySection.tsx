import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight } from "lucide-react";
import { Category } from "@shared/schema";

// Use Lucide icons dynamically based on icon string
import * as LucideIcons from "lucide-react";

export default function CategorySection() {
  const { data: categories, isLoading } = useQuery({
    queryKey: ["/api/categories"],
  });

  if (isLoading) {
    return <CategorySectionSkeleton />;
  }

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-slate-800">Shop by Category</h2>
          <Link href="/products" className="text-primary hover:text-primary-700 font-medium flex items-center">
            View All 
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {categories?.map((category: Category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>
    </section>
  );
}

interface CategoryCardProps {
  category: Category;
}

function CategoryCard({ category }: CategoryCardProps) {
  const [Icon, setIcon] = useState<React.ComponentType<any> | null>(null);

  useEffect(() => {
    // Parse icon name and get corresponding Lucide icon
    const iconName = category.icon.replace(/-line|-fill/g, '');
    // Convert to PascalCase for Lucide imports
    const pascalCase = iconName.replace(/(^|-)([a-z])/g, (_, __, char) => char.toUpperCase());
    
    if (LucideIcons[pascalCase as keyof typeof LucideIcons]) {
      setIcon(() => LucideIcons[pascalCase as keyof typeof LucideIcons]);
    } else {
      // Fallback icon
      setIcon(() => LucideIcons.Package);
    }
  }, [category.icon]);

  return (
    <Link 
      href={`/products?category=${category.slug}`}
      className="bg-slate-50 hover:bg-slate-100 p-4 rounded-lg text-center transition duration-200"
    >
      <div className="w-12 h-12 mx-auto mb-3 bg-primary-100 text-primary rounded-full flex items-center justify-center">
        {Icon && <Icon className="h-5 w-5" />}
      </div>
      <h3 className="font-medium text-slate-800">{category.name}</h3>
    </Link>
  );
}

function CategorySectionSkeleton() {
  // Create an array of 6 items for the skeleton
  const skeletonItems = Array(6).fill(null);

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div className="h-8 bg-slate-200 rounded w-48 animate-pulse" />
          <div className="h-4 bg-slate-200 rounded w-24 animate-pulse" />
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {skeletonItems.map((_, index) => (
            <div key={index} className="bg-slate-50 p-4 rounded-lg text-center">
              <div className="w-12 h-12 mx-auto mb-3 bg-slate-200 rounded-full animate-pulse" />
              <div className="h-4 bg-slate-200 rounded w-16 mx-auto animate-pulse" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
