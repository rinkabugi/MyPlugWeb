import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function BannerSection() {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1519677584237-752f8853252e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&h=600&q=80" 
            alt="Kenyan marketplace banner" 
            className="w-full h-64 md:h-80 object-cover" 
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-primary/30 flex items-center">
            <div className="p-6 md:p-12 max-w-lg">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Flash Sale - Up to 50% Off!
              </h2>
              <p className="text-white text-lg mb-6">
                Limited time offers on our most popular items. Don't miss out!
              </p>
              <Button 
                variant="outline" 
                size="lg"
                className="bg-white hover:bg-slate-100 text-primary border-white"
                asChild
              >
                <Link href="/products?featured=true">Shop the Sale</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
