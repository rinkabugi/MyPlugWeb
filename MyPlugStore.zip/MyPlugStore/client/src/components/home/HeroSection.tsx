import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section className="relative bg-black h-[60vh] sm:h-[70vh] flex items-center">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://pixabay.com/get/gdd97c6d16ad7911c40f12d0d711242f8ce48f5dc722744c40c45a5e6b08b4fc689658b7b7c38a9181bc853292f81baa17c81f95ad366163cbb319cd81316b7e3_1280.jpg" 
          alt="Kenyan marketplace" 
          className="w-full h-full object-cover opacity-50" 
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black to-transparent"></div>
      </div>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-lg">
          <div className="flex items-center mb-6">
            <img src="/assets/plug-logo.jpg" alt="THE PLUG" className="h-14 w-14 mr-3 rounded-full" />
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-1">
                <span className="text-white">THE</span>
                <span className="text-secondary">PLUG</span>
              </h1>
              <p className="text-gray-400 text-sm">Connect • Limitless • Possibilities</p>
            </div>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Your One-Stop Shop for Everything
          </h2>
          <p className="text-white text-lg mb-8">
            Discover quality products from trusted sellers across Kenya.
            Shop with our native <span className="text-secondary font-medium">PLUG Token</span> for exclusive benefits.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button asChild size="lg" className="bg-secondary hover:bg-secondary/90 text-white border-none">
              <Link href="/products">Shop Now</Link>
            </Button>
            <Button variant="outline" size="lg" className="border-secondary text-secondary hover:bg-secondary/10">
              <Link href="/become-seller">Become a Seller</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
