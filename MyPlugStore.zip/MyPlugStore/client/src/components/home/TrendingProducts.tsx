import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import ProductCard from "@/components/products/ProductCard";
import { Product } from "@shared/schema";

export default function TrendingProducts() {
  const { data: products, isLoading, error } = useQuery({
    queryKey: ["/api/products", { trending: true, limit: 4 }],
  });

  if (isLoading) {
    return <TrendingProductsSkeleton />;
  }

  if (error || !products) {
    return (
      <div className="py-12 bg-slate-50 text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-slate-800 mb-4">Trending Now</h2>
          <p className="text-slate-600">
            Sorry, we couldn't load the trending products. Please try again later.
          </p>
        </div>
      </div>
    );
  }

  return (
    <section className="py-12 bg-slate-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-slate-800">Trending Now</h2>
          <Link 
            href="/products?trending=true"
            className="text-primary hover:text-primary-700 font-medium flex items-center"
          >
            View All 
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {Array.isArray(products) && products.map((product: Product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}

function TrendingProductsSkeleton() {
  // Create an array of 4 items for the skeleton
  const skeletonItems = Array(4).fill(null);

  return (
    <section className="py-12 bg-slate-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div className="h-8 bg-slate-200 rounded w-48 animate-pulse" />
          <div className="h-4 bg-slate-200 rounded w-24 animate-pulse" />
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {skeletonItems.map((_, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="h-60 bg-slate-200 animate-pulse" />
              <div className="p-4 space-y-2">
                <div className="h-3 bg-slate-200 rounded animate-pulse" />
                <div className="h-5 bg-slate-200 rounded w-3/4 animate-pulse" />
                <div className="flex space-x-1">
                  {Array(5).fill(null).map((_, i) => (
                    <div key={i} className="h-4 w-4 bg-slate-200 rounded-full animate-pulse" />
                  ))}
                </div>
                <div className="flex justify-between items-center pt-2">
                  <div className="h-6 bg-slate-200 rounded w-20 animate-pulse" />
                  <div className="h-8 w-8 bg-slate-200 rounded-lg animate-pulse" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
