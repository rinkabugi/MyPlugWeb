import { Button } from "@/components/ui/button";
import { Wallet, Shield, Tag, CreditCard, ExternalLink } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function TokenSection() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleBuyToken = () => {
    setIsLoading(true);
    // Redirect to pump.fun for the token address
    window.open("https://pump.fun/token/6nBZsNXjc2BwfPpJeqiQkYHbgQKYcT5MG1oQeT7Hpump", "_blank");
    setIsLoading(false);
    toast({
      title: "Opening exchange",
      description: "Redirecting you to purchase PLUG tokens on pump.fun",
    });
  };

  const handleViewDashboard = () => {
    window.open("https://solscan.io/token/6nBZsNXjc2BwfPpJeqiQkYHbgQKYcT5MG1oQeT7Hpump", "_blank");
    toast({
      title: "Opening dashboard",
      description: "Redirecting you to the PLUG token dashboard",
    });
  };
  
  return (
    <section className="py-12 bg-black text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Token Info */}
          <div className="w-full md:w-1/2 space-y-6">
            <div className="flex items-center">
              <img src="/assets/plug-logo.jpg" alt="THE PLUG" className="h-16 w-16 mr-4 rounded-full" />
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-2">
                  <span className="text-white">THE</span>
                  <span className="text-secondary">PLUG</span> Token
                </h2>
                <p className="text-gray-400">Connect • Limitless • Possibilities</p>
              </div>
            </div>
            
            <p className="text-lg">
              Unlock exclusive benefits and discounts when you shop with our native token.
              Join our community of token holders and enjoy premium features.
            </p>
            
            <div className="bg-gray-900 p-4 rounded-lg border border-gray-800">
              <p className="text-gray-400 mb-2">Contract Address:</p>
              <p className="font-mono text-secondary text-sm break-all">
                6nBZsNXjc2BwfPpJeqiQkYHbgQKYcT5MG1oQeT7Hpump
              </p>
            </div>
            
            <div className="flex flex-wrap gap-4">
              <Button 
                className="bg-secondary hover:bg-secondary/90"
                onClick={handleBuyToken}
                disabled={isLoading}
              >
                <Wallet className="mr-2 h-4 w-4" />
                Buy PLUG Token
                {isLoading && <span className="ml-2 animate-spin">↻</span>}
              </Button>
              <Button 
                variant="outline" 
                className="border-secondary text-secondary hover:bg-secondary/10"
                onClick={handleViewDashboard}
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Token Dashboard
              </Button>
            </div>
          </div>
          
          {/* Benefits Cards */}
          <div className="w-full md:w-1/2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-gray-900 p-4 rounded-lg border border-gray-800">
                <div className="w-10 h-10 bg-secondary/20 text-secondary rounded-full flex items-center justify-center mb-3">
                  <Tag className="h-5 w-5" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Exclusive Discounts</h3>
                <p className="text-gray-400">
                  Get up to 15% discount on all purchases when you pay with PLUG tokens.
                </p>
              </div>
              
              <div className="bg-gray-900 p-4 rounded-lg border border-gray-800">
                <div className="w-10 h-10 bg-secondary/20 text-secondary rounded-full flex items-center justify-center mb-3">
                  <Shield className="h-5 w-5" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Members-Only Items</h3>
                <p className="text-gray-400">
                  Access exclusive products available only to PLUG token holders.
                </p>
              </div>
              
              <div className="bg-gray-900 p-4 rounded-lg border border-gray-800">
                <div className="w-10 h-10 bg-secondary/20 text-secondary rounded-full flex items-center justify-center mb-3">
                  <CreditCard className="h-5 w-5" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Cashback Rewards</h3>
                <p className="text-gray-400">
                  Earn 5% cashback in PLUG tokens on every purchase you make.
                </p>
              </div>
              
              <div className="bg-gray-900 p-4 rounded-lg border border-gray-800">
                <div className="w-10 h-10 bg-secondary/20 text-secondary rounded-full flex items-center justify-center mb-3">
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="20" 
                    height="20" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="text-secondary"
                  >
                    <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                    <path d="M2 17l10 5 10-5"></path>
                    <path d="M2 12l10 5 10-5"></path>
                  </svg>
                </div>
                <h3 className="font-semibold text-lg mb-2">Staking Rewards</h3>
                <p className="text-gray-400">
                  Stake your PLUG tokens and earn passive income through rewards.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}