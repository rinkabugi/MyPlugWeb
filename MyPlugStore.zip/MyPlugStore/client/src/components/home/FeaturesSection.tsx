import { Truck, ShieldCheck, Clock, HeadphonesIcon } from "lucide-react";

interface FeatureItem {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const features: FeatureItem[] = [
  {
    icon: <Truck className="text-2xl" />,
    title: "Fast Delivery",
    description: "Quick delivery across Kenya, with real-time tracking of your orders."
  },
  {
    icon: <ShieldCheck className="text-2xl" />,
    title: "Secure Payments",
    description: "Multiple payment options including M-Pesa, cards, and cash on delivery."
  },
  {
    icon: <Clock className="text-2xl" />,
    title: "Quality Guarantee",
    description: "All products are verified for quality and authenticity before shipping."
  },
  {
    icon: <HeadphonesIcon className="text-2xl" />,
    title: "24/7 Support",
    description: "Our customer service team is always ready to assist you with any queries."
  }
];

export default function FeaturesSection() {
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-bold text-slate-800 text-center mb-12">Why Shop With Us</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div className="text-center" key={index}>
              <div className="w-16 h-16 bg-primary-100 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
                {feature.icon}
              </div>
              <h3 className="font-semibold text-lg text-slate-800 mb-2">{feature.title}</h3>
              <p className="text-slate-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
