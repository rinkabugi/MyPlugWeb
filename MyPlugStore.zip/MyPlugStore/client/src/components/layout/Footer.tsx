import { Link } from "wouter";
import { Facebook, Twitter, Instagram, MapPin, Phone, Mail, Clock } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-sidebar text-sidebar-foreground">
      {/* Main Footer */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <img src="/assets/plug-logo.jpg" alt="THE PLUG" className="h-10 w-10 mr-2 rounded-full" />
              <h3 className="text-white text-lg font-semibold">
                <span className="text-white">THE</span>
                <span className="text-secondary">PLUG</span>
              </h3>
            </div>
            <p className="mb-4">Your trusted marketplace for quality products in Kenya.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-sidebar-foreground hover:text-white">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-sidebar-foreground hover:text-white">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-sidebar-foreground hover:text-white">
                <Instagram size={20} />
              </a>
            </div>
          </div>
          
          {/* Useful Links */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Useful Links</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="hover:text-white">About Us</Link></li>
              <li><Link href="/terms" className="hover:text-white">Terms & Conditions</Link></li>
              <li><Link href="/privacy" className="hover:text-white">Privacy Policy</Link></li>
              <li><Link href="/shipping" className="hover:text-white">Shipping & Delivery</Link></li>
              <li><Link href="/returns" className="hover:text-white">Returns & Refunds</Link></li>
            </ul>
          </div>
          
          {/* Customer Service */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li><Link href="/contact" className="hover:text-white">Contact Us</Link></li>
              <li><Link href="/faq" className="hover:text-white">FAQs</Link></li>
              <li><Link href="/track-order" className="hover:text-white">Track Your Order</Link></li>
              <li><Link href="/report-issue" className="hover:text-white">Report an Issue</Link></li>
              <li><Link href="/become-seller" className="hover:text-white">Become a Seller</Link></li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin className="mt-1 mr-2 h-4 w-4" />
                <span>Nairobi, Kenya</span>
              </li>
              <li className="flex items-start">
                <Phone className="mt-1 mr-2 h-4 w-4" />
                <span>+254 700 000 000</span>
              </li>
              <li className="flex items-start">
                <Mail className="mt-1 mr-2 h-4 w-4" />
                <span>info@myplug.co.ke</span>
              </li>
              <li className="flex items-start">
                <Clock className="mt-1 mr-2 h-4 w-4" />
                <span>Mon-Fri: 8am - 6pm</span>
              </li>
            </ul>
          </div>
          
          {/* PLUG Token Info */}
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">PLUG Token</h3>
            <p className="mb-2">The official token of THE PLUG marketplace. Hold to receive discounts and rewards.</p>
            <div className="bg-black/30 p-2 rounded overflow-hidden mb-2">
              <p className="text-secondary font-mono text-xs break-all">6nBZsNXjc2BwfPpJeqiQkYHbgQKYcT5MG1oQeT7Hpump</p>
            </div>
            <div className="flex space-x-2">
              <a href="https://pump.fun" target="_blank" rel="noopener noreferrer" className="bg-secondary text-white text-xs px-2 py-1 rounded hover:bg-secondary/80">
                Buy on pump.fun
              </a>
              <a href="#" className="bg-gray-700 text-white text-xs px-2 py-1 rounded hover:bg-gray-600">
                Token Info
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Bottom Footer */}
      <div className="border-t border-sidebar-border py-6">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex flex-col md:flex-row items-center">
            <p className="text-center md:text-left mb-2 md:mb-0 md:mr-4">
              &copy; {currentYear} THE PLUG. All Rights Reserved.
            </p>
            <div className="flex items-center space-x-1 mb-4 md:mb-0">
              <span className="text-xs bg-black border border-secondary text-secondary px-2 py-1 rounded-l">
                Token
              </span>
              <span className="text-xs bg-secondary text-white px-2 py-1 rounded-r font-mono">
                6nBZsNXj...7Hpump
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Payment method images replaced with text for simplicity */}
            <span className="text-xs bg-white text-black px-2 py-1 rounded">M-PESA</span>
            <span className="text-xs bg-white text-black px-2 py-1 rounded">VISA</span>
            <span className="text-xs bg-white text-black px-2 py-1 rounded">MasterCard</span>
            <span className="text-xs bg-secondary text-white px-2 py-1 rounded">PLUG Token</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
