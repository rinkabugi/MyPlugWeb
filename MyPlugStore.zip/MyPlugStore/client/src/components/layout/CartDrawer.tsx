import { useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/useCart";
import { X, Trash2, Plus, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

export default function CartDrawer() {
  const { 
    isCartOpen, 
    toggleCart, 
    cart, 
    updateCartItemQuantity,
    removeCartItem,
    cartEmpty
  } = useCart();

  // Prevent scrolling when cart drawer is open
  useEffect(() => {
    if (isCartOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    
    return () => {
      document.body.style.overflow = "";
    };
  }, [isCartOpen]);

  if (!cart) {
    return null;
  }

  return (
    <>
      {/* Backdrop overlay */}
      <div 
        className={cn(
          "fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity",
          isCartOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={toggleCart}
      />

      {/* Cart drawer */}
      <div 
        className={cn(
          "fixed top-0 right-0 h-full w-full sm:w-96 bg-white shadow-lg z-50 transition-transform duration-300 ease-in-out",
          isCartOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        <div className="flex flex-col h-full">
          {/* Cart Header */}
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-800">
              Your Cart ({cart.items.length})
            </h3>
            <Button variant="ghost" size="icon" onClick={toggleCart}>
              <X className="h-5 w-5" />
            </Button>
          </div>
          
          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
            {cart.items.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="mb-4 text-slate-400">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-12 w-12 mx-auto"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
                    />
                  </svg>
                </div>
                <h4 className="text-lg font-medium text-slate-900 mb-2">Your cart is empty</h4>
                <p className="text-slate-500 mb-4">Looks like you haven't added any products to your cart yet.</p>
                <Button onClick={toggleCart}>Continue Shopping</Button>
              </div>
            ) : (
              cart.items.map((item) => (
                <div key={item.id} className="flex items-start space-x-4 border-b border-slate-200 pb-4">
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    className="w-16 h-16 object-cover rounded"
                  />
                  
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-slate-800 line-clamp-2">{item.name}</h4>
                    <p className="text-xs text-slate-500 mt-1">{item.categoryName}</p>
                    
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center border border-slate-300 rounded">
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="icon" 
                          className="h-7 w-7 rounded-none text-slate-600 hover:text-primary p-1"
                          onClick={() => updateCartItemQuantity(item.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="w-8 text-center text-sm border-x border-slate-300 py-1">
                          {item.quantity}
                        </span>
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="icon" 
                          className="h-7 w-7 rounded-none text-slate-600 hover:text-primary p-1"
                          onClick={() => updateCartItemQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                      <span className="font-semibold text-slate-800">
                        KSh {(item.price * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-slate-400 hover:text-secondary"
                    onClick={() => removeCartItem(item.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))
            )}
          </div>
          
          {/* Cart Summary */}
          {cart.items.length > 0 && (
            <div className="p-4 border-t border-slate-200 bg-slate-50">
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-slate-600">Subtotal</span>
                  <span className="font-medium">KSh {cart.subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Shipping</span>
                  <span className="font-medium">KSh {cart.shipping.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Tax</span>
                  <span className="font-medium">KSh {cart.tax.toLocaleString()}</span>
                </div>
                <div className="pt-2 border-t border-slate-200 flex justify-between">
                  <span className="font-semibold text-slate-800">Total</span>
                  <span className="font-bold text-slate-800">KSh {cart.total.toLocaleString()}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Link href="/checkout">
                  <Button 
                    className="w-full" 
                    onClick={toggleCart}
                  >
                    Proceed to Checkout
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  className="w-full text-primary border-primary"
                  onClick={toggleCart}
                >
                  Continue Shopping
                </Button>
                <Button 
                  variant="ghost" 
                  className="w-full text-destructive"
                  onClick={cartEmpty}
                >
                  Empty Cart
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
