import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Search } from "@/components/ui/search";
import { useCart } from "@/hooks/useCart";
import { cn } from "@/lib/utils";
import { ShoppingCart, User, Menu } from "lucide-react";

interface NavItem {
  label: string;
  href: string;
}

const navItems: NavItem[] = [
  { label: "Home", href: "/" },
  { label: "Shop", href: "/products" },
  { label: "Categories", href: "/products" },
  { label: "Deals", href: "/products?featured=true" },
  { label: "Contact", href: "/contact" },
  { label: "Admin", href: "/admin/dashboard" },
];

export default function Header() {
  const [location] = useLocation();
  const { toggleCart, cartItemsCount } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="bg-black shadow-sm sticky top-0 z-30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <img src="/assets/plug-logo.jpg" alt="THE PLUG" className="h-10 w-10 mr-2 rounded-full" />
              <h1 className="text-2xl font-bold">
                <span className="text-white">THE</span>
                <span className="text-secondary">PLUG</span>
              </h1>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navItems.map((item) => (
              <Link key={item.label} href={item.href} 
                className={cn(
                  "text-white hover:text-secondary font-medium",
                  location === item.href && "text-secondary"
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Search Bar (Desktop) */}
          <div className="hidden md:flex flex-1 max-w-md mx-6">
            <Search />
          </div>

          {/* Right Actions */}
          <div className="flex items-center space-x-4">
            {/* Account Icon */}
            <Button variant="ghost" size="icon" className="text-white hover:text-secondary">
              <User className="h-5 w-5" />
            </Button>

            {/* Cart Icon */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-white hover:text-secondary relative"
              onClick={toggleCart}
            >
              <ShoppingCart className="h-5 w-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-secondary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemsCount}
                </span>
              )}
            </Button>

            {/* Mobile Menu Button */}
            <Button 
              variant="ghost" 
              size="icon"
              className="md:hidden text-white hover:text-secondary"
              onClick={toggleMobileMenu}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Mobile Search (visible on small screens) */}
        <div className="md:hidden py-2">
          <Search />
        </div>
      </div>

      {/* Mobile Menu (hidden by default) */}
      <div className={cn("md:hidden", !mobileMenuOpen && "hidden")}>
        <div className="px-2 pt-2 pb-3 space-y-1 bg-black border-t border-gray-800">
          {navItems.map((item) => (
            <Link 
              key={item.label} 
              href={item.href}
              className={cn(
                "block px-3 py-2 rounded-md text-base font-medium text-white hover:bg-gray-900",
                location === item.href && "text-secondary"
              )}
              onClick={() => setMobileMenuOpen(false)}
            >
              {item.label}
            </Link>
          ))}
        </div>
      </div>
    </header>
  );
}