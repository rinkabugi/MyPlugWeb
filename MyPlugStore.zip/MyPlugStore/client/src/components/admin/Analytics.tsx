
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface AnalyticsProps {
  products: any[];
  categories: any[];
}

export default function Analytics({ products, categories }: AnalyticsProps) {
  if (!products || !categories) {
    return <div>Loading analytics...</div>;
  }

  // Calculate category distribution
  const categoryStats = categories.map((category: any) => {
    const categoryProducts = products.filter((p: any) => p.categoryId === category.id);
    const percentage = (categoryProducts.length / products.length) * 100;
    return {
      name: category.name,
      count: categoryProducts.length,
      percentage: percentage.toFixed(1),
    };
  });

  // Calculate price ranges
  const priceRanges = [
    { label: "Under KSh 1,000", min: 0, max: 1000 },
    { label: "KSh 1,000 - 5,000", min: 1000, max: 5000 },
    { label: "KSh 5,000 - 10,000", min: 5000, max: 10000 },
    { label: "KSh 10,000 - 50,000", min: 10000, max: 50000 },
    { label: "Over KSh 50,000", min: 50000, max: Infinity },
  ];

  const priceStats = priceRanges.map((range) => {
    const count = products.filter((p: any) => {
      const price = Number(p.price);
      return price >= range.min && price < range.max;
    }).length;
    const percentage = (count / products.length) * 100;
    return {
      ...range,
      count,
      percentage: percentage.toFixed(1),
    };
  });

  // Calculate average rating
  const avgRating = products.reduce((sum: number, p: any) => sum + Number(p.rating), 0) / products.length;

  // Stock status
  const inStock = products.filter((p: any) => p.inStock).length;
  const outOfStock = products.length - inStock;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Category Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Products by Category</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {categoryStats.map((stat: any) => (
              <div key={stat.name}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">{stat.name}</span>
                  <span className="text-sm text-slate-500">
                    {stat.count} ({stat.percentage}%)
                  </span>
                </div>
                <Progress value={Number(stat.percentage)} />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Price Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Price Distribution</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {priceStats.map((stat: any) => (
              <div key={stat.label}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">{stat.label}</span>
                  <span className="text-sm text-slate-500">
                    {stat.count} ({stat.percentage}%)
                  </span>
                </div>
                <Progress value={Number(stat.percentage)} />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Stock Status */}
        <Card>
          <CardHeader>
            <CardTitle>Stock Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">In Stock</span>
                  <span className="text-sm text-slate-500">
                    {inStock} ({((inStock / products.length) * 100).toFixed(1)}%)
                  </span>
                </div>
                <Progress value={(inStock / products.length) * 100} className="bg-green-100" />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm font-medium">Out of Stock</span>
                  <span className="text-sm text-slate-500">
                    {outOfStock} ({((outOfStock / products.length) * 100).toFixed(1)}%)
                  </span>
                </div>
                <Progress value={(outOfStock / products.length) * 100} className="bg-red-100" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Product Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Product Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Average Rating</span>
                <span className="text-2xl font-bold">{avgRating.toFixed(1)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Total Reviews</span>
                <span className="text-2xl font-bold">
                  {products.reduce((sum: number, p: any) => sum + p.reviews, 0)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Featured Products</span>
                <span className="text-2xl font-bold">
                  {products.filter((p: any) => p.featured).length}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Trending Products</span>
                <span className="text-2xl font-bold">
                  {products.filter((p: any) => p.trending).length}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
