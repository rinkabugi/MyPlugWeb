# Overview

THE PLUG is a comprehensive e-commerce marketplace application designed specifically for the Kenyan market. The platform serves as a one-stop shop connecting buyers with trusted sellers across Kenya, featuring a unique integration with a native PLUG token for enhanced user benefits. The application provides a complete shopping experience with product browsing, cart management, secure checkout, and newsletter subscription functionality.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built using React with TypeScript, implementing a modern component-based architecture. The application uses Wouter for client-side routing, providing a lightweight alternative to React Router. State management is handled through React Context API for cart functionality and React Query (TanStack Query) for server state management and caching.

The UI framework leverages Radix UI primitives with shadcn/ui components, styled using Tailwind CSS for responsive design. The component structure follows atomic design principles with reusable UI components, layout components, and page-specific components organized in a clear hierarchy.

## Backend Architecture
The backend follows a RESTful API architecture built with Express.js and TypeScript. The server implements a layered architecture with clear separation between routes, storage, and business logic. The application uses an in-memory storage implementation (MemStorage) that implements the IStorage interface, allowing for easy migration to persistent storage solutions.

API endpoints are organized with a consistent `/api` prefix and include comprehensive error handling middleware. The server includes request logging and response capture for debugging and monitoring purposes.

## Data Storage Solutions
The application uses Drizzle ORM with PostgreSQL for database operations, configured for serverless deployment with Neon Database. The schema defines core entities including users, categories, products, carts, cart items, and newsletter subscriptions. The database design supports product categorization, shopping cart functionality, and user management with proper foreign key relationships.

Database migrations are managed through Drizzle Kit, ensuring consistent schema updates across environments. The configuration supports both development and production database connections through environment variables.

## Authentication and Authorization
The current implementation includes user schema and password handling, though specific authentication middleware is not yet implemented. The system is prepared for session-based authentication with password hashing capabilities.

## Frontend State Management
Cart state is managed through React Context, providing global access to cart operations including adding items, updating quantities, and removing products. The cart persists across browser sessions using localStorage with a unique cart identifier.

React Query handles all server state, providing automatic caching, background updates, and error handling for API requests. This approach ensures optimal performance and user experience with minimal loading states.

## UI/UX Design System
The application implements a comprehensive design system using shadcn/ui components built on Radix UI primitives. The design features a dark theme with customizable CSS variables, supporting both light and dark modes. Color schemes use semantic naming conventions for consistent theming.

Typography uses the Inter font family for optimal readability, while the layout follows responsive design principles with mobile-first approach. The component library includes all common UI patterns including forms, navigation, modals, and data display components.

# External Dependencies

## Third-Party Services
- **Neon Database**: Serverless PostgreSQL hosting for production data storage
- **Stripe**: Payment processing integration for secure transactions (React Stripe.js)
- **pump.fun**: External token exchange platform for PLUG token purchases

## Development and Build Tools
- **Vite**: Frontend build tool and development server with hot module replacement
- **Replit**: Development environment with integrated deployment and collaboration features
- **ESBuild**: Fast JavaScript bundler for production builds

## UI and Styling Libraries
- **Radix UI**: Unstyled, accessible UI primitives for complex components
- **Tailwind CSS**: Utility-first CSS framework for rapid styling
- **Lucide React**: Icon library providing consistent iconography
- **shadcn/ui**: Pre-built component library built on Radix UI

## Core Dependencies
- **React Query (TanStack Query)**: Server state management and caching
- **React Hook Form**: Form state management with validation
- **Zod**: Runtime type validation for forms and API responses
- **Drizzle ORM**: Type-safe SQL query builder and schema management
- **Wouter**: Lightweight client-side routing for React

## Additional Libraries
- **uuid**: Unique identifier generation for cart and session management
- **class-variance-authority**: Type-safe component variant management
- **clsx & tailwind-merge**: Utility functions for conditional CSS classes
- **React Helmet**: Document head management for SEO optimization

The application is designed to run seamlessly on Replit with optimized configuration for their hosting environment, including specialized plugins for error handling and development tools integration.