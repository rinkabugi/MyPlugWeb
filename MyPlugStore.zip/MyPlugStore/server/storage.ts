import { v4 as uuidv4 } from "uuid";
import {
  type User, type InsertUser,
  type Category, type InsertCategory,
  type Product, type InsertProduct,
  type Cart, type CartItem,
  type Newsletter, type InsertNewsletter
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Category methods
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Product methods
  getProducts(options?: {
    categoryId?: number;
    featured?: boolean;
    trending?: boolean;
    limit?: number;
    search?: string;
  }): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: InsertProduct): Promise<Product>;
  deleteProduct(id: number): Promise<void>;

  // Cart methods
  getCart(cartId: string): Promise<Cart | undefined>;
  createCart(): Promise<Cart>;
  addToCart(cartId: string, productId: number, quantity: number): Promise<Cart>;
  updateCartItem(cartId: string, itemId: number, quantity: number): Promise<Cart>;
  removeFromCart(cartId: string, itemId: number): Promise<Cart>;

  // Newsletter methods
  subscribeToNewsletter(email: string): Promise<Newsletter>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private carts: Map<string, Cart>;
  private newsletters: Map<number, Newsletter>;

  private userIdCounter: number;
  private categoryIdCounter: number;
  private productIdCounter: number;
  private newsletterIdCounter: number;
  private cartItemIdCounter: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.products = new Map();
    this.carts = new Map();
    this.newsletters = new Map();

    this.userIdCounter = 1;
    this.categoryIdCounter = 1;
    this.productIdCounter = 1;
    this.newsletterIdCounter = 1;
    this.cartItemIdCounter = 1;

    this.initializeData();
  }

  private initializeData() {
    // Create categories
    const categoriesData: InsertCategory[] = [
      { name: "Electronics", slug: "electronics", icon: "smartphone-line" },
      { name: "Fashion", slug: "fashion", icon: "t-shirt-line" },
      { name: "Home", slug: "home", icon: "home-line" },
      { name: "Health", slug: "health", icon: "heart-pulse-line" },
      { name: "Gaming", slug: "gaming", icon: "game-line" },
      { name: "Food", slug: "food", icon: "restaurant-line" },
    ];

    for (const category of categoriesData) {
      this.createCategory(category);
    }

    // Create products
    const productsData: InsertProduct[] = [
      {
        name: "Premium Smartphone - 128GB Storage",
        slug: "premium-smartphone",
        description: "The latest smartphone with cutting-edge features and 128GB of storage.",
        price: "24999",
        comparePrice: "29999",
        imageUrl: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=400&q=80",
        categoryId: 1,
        rating: "4.5",
        reviews: 42,
        featured: true,
        trending: false,
        inStock: true,
        badge: null,
      },
      {
        name: "Wireless Noise Cancelling Headphones",
        slug: "wireless-headphones",
        description: "Premium wireless headphones with active noise cancellation for an immersive audio experience.",
        price: "6499",
        comparePrice: "8999",
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=400&q=80",
        categoryId: 1,
        rating: "4.0",
        reviews: 28,
        featured: true,
        trending: false,
        inStock: true,
        badge: null,
      },
      {
        name: "Ultra-Slim Laptop - 8GB RAM, 512GB SSD",
        slug: "ultra-slim-laptop",
        description: "Powerful and portable laptop with 8GB RAM and fast 512GB SSD storage.",
        price: "59999",
        comparePrice: "69999",
        imageUrl: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=400&q=80",
        categoryId: 1,
        rating: "5.0",
        reviews: 56,
        featured: true,
        trending: false,
        inStock: true,
        badge: "HOT DEAL",
      },
      {
        name: "Fitness Smartwatch with Heart Rate Monitor",
        slug: "fitness-smartwatch",
        description: "Track your fitness goals with this advanced smartwatch featuring heart rate monitoring.",
        price: "7999",
        comparePrice: "9499",
        imageUrl: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=400&q=80",
        categoryId: 1,
        rating: "3.5",
        reviews: 19,
        featured: true,
        trending: false,
        inStock: true,
        badge: null,
      },
      {
        name: "Handcrafted Beaded Jewelry Set",
        slug: "beaded-jewelry-set",
        description: "Beautiful handcrafted beaded jewelry set made by local Kenyan artisans.",
        price: "2499",
        comparePrice: "3499",
        imageUrl: "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=400&q=80",
        categoryId: 2,
        rating: "4.5",
        reviews: 34,
        featured: false,
        trending: true,
        inStock: true,
        badge: "TRENDING",
      },
      {
        name: "Traditional Kente Fabric Wrap",
        slug: "kente-fabric-wrap",
        description: "Authentic traditional Kente fabric wrap, perfect for special occasions.",
        price: "1899",
        comparePrice: null,
        imageUrl: "https://images.unsplash.com/photo-1583846783214-7229a91b20ed?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&h=400&q=80",
        categoryId: 2,
        rating: "5.0",
        reviews: 52,
        featured: false,
        trending: true,
        inStock: true,
        badge: null,
      },
      {
        name: "Compact Electric Kettle - 1.7L",
        slug: "electric-kettle",
        description: "Efficient 1.7L electric kettle for quick and convenient hot water.",
        price: "2199",
        comparePrice: "2799",
        imageUrl: "https://pixabay.com/get/gaf2d81923359e169f605c1dea61ca305891a744cef8b34ba1636f78d8853258653f2e47d56a75eae769a5c9ca836d53107b2ce5277fba9cd3bfda9db33aca97b_1280.jpg",
        categoryId: 3,
        rating: "4.0",
        reviews: 87,
        featured: false,
        trending: true,
        inStock: true,
        badge: "BEST SELLER",
      },
      {
        name: "Premium Kenyan Coffee Beans - 500g",
        slug: "kenyan-coffee-beans",
        description: "Freshly roasted premium Kenyan coffee beans, packed with rich flavor.",
        price: "899",
        comparePrice: "1199",
        imageUrl: "https://pixabay.com/get/gb18c18aeb2e2e07ce0fc85a2d625f8be7cdb7919835314194227eb7641ca1b5ba4f8df5bcdb26f22bf1cf64b2c445f6102f440d540e2a9cf208ae57af204d10f_1280.jpg",
        categoryId: 6,
        rating: "4.5",
        reviews: 43,
        featured: false,
        trending: true,
        inStock: true,
        badge: null,
      },
    ];

    for (const product of productsData) {
      this.createProduct(product);
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug,
    );
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  // Product methods
  async getProducts(options: {
    categoryId?: number;
    featured?: boolean;
    trending?: boolean;
    limit?: number;
    search?: string;
  } = {}): Promise<Product[]> {
    let products = Array.from(this.products.values());

    if (options.categoryId) {
      products = products.filter(product => product.categoryId === options.categoryId);
    }

    if (options.featured !== undefined) {
      products = products.filter(product => product.featured === options.featured);
    }

    if (options.trending !== undefined) {
      products = products.filter(product => product.trending === options.trending);
    }

    if (options.search) {
      const searchTerm = options.search.toLowerCase();
      products = products.filter(product => 
        product.name.toLowerCase().includes(searchTerm) || 
        product.description.toLowerCase().includes(searchTerm)
      );
    }

    if (options.limit) {
      products = products.slice(0, options.limit);
    }

    return products;
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.slug === slug,
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const product: Product = { 
      ...insertProduct, 
      id,
      rating: insertProduct.rating ?? "0",
      reviews: insertProduct.reviews ?? 0,
      featured: insertProduct.featured ?? false,
      trending: insertProduct.trending ?? false,
      inStock: insertProduct.inStock ?? true,
      badge: insertProduct.badge ?? null,
      comparePrice: insertProduct.comparePrice ?? null,
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: number, data: InsertProduct): Promise<Product> {
    const product = this.products.get(id);
    if (!product) {
      throw new Error("Product not found");
    }

    const updatedProduct: Product = {
      ...product,
      ...data,
      id: product.id, // Ensure ID doesn't change
      rating: data.rating ?? product.rating,
      reviews: data.reviews ?? product.reviews,
      featured: data.featured ?? product.featured,
      trending: data.trending ?? product.trending,
      inStock: data.inStock ?? product.inStock,
      badge: data.badge ?? product.badge,
      comparePrice: data.comparePrice ?? product.comparePrice,
    };

    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<void> {
    const deleted = this.products.delete(id);
    if (!deleted) {
      throw new Error("Product not found");
    }
  }

  // Cart methods
  async getCart(cartId: string): Promise<Cart | undefined> {
    return this.carts.get(cartId);
  }

  async createCart(): Promise<Cart> {
    const cart: Cart = {
      id: uuidv4(),
      items: [],
      subtotal: 0,
      shipping: 400, // Default shipping cost
      tax: 0,
      total: 0,
    };

    this.carts.set(cart.id, cart);
    return cart;
  }

  async addToCart(cartId: string, productId: number, quantity: number): Promise<Cart> {
    const cart = this.carts.get(cartId);
    if (!cart) throw new Error("Cart not found");

    const product = this.products.get(productId);
    if (!product) throw new Error("Product not found");

    // Check if product already exists in cart
    const existingItemIndex = cart.items.findIndex(item => item.productId === productId);

    if (existingItemIndex !== -1) {
      // Update quantity if product already in cart
      cart.items[existingItemIndex].quantity += quantity;
    } else {
      // Add new item to cart
      const category = this.categories.get(product.categoryId);

      const cartItem: CartItem = {
        id: this.cartItemIdCounter++,
        productId: product.id,
        quantity,
        name: product.name,
        price: Number(product.price),
        imageUrl: product.imageUrl,
        categoryName: category ? category.name : "Unknown",
      };

      cart.items.push(cartItem);
    }

    // Recalculate totals
    this.recalculateCart(cart);

    return cart;
  }

  async updateCartItem(cartId: string, itemId: number, quantity: number): Promise<Cart> {
    const cart = this.carts.get(cartId);
    if (!cart) throw new Error("Cart not found");

    const itemIndex = cart.items.findIndex(item => item.id === itemId);
    if (itemIndex === -1) throw new Error("Cart item not found");

    if (quantity <= 0) {
      // Remove item if quantity is zero or negative
      return this.removeFromCart(cartId, itemId);
    }

    // Update quantity
    cart.items[itemIndex].quantity = quantity;

    // Recalculate totals
    this.recalculateCart(cart);

    return cart;
  }

  async removeFromCart(cartId: string, itemId: number): Promise<Cart> {
    const cart = this.carts.get(cartId);
    if (!cart) throw new Error("Cart not found");

    cart.items = cart.items.filter(item => item.id !== itemId);

    // Recalculate totals
    this.recalculateCart(cart);

    return cart;
  }

  private recalculateCart(cart: Cart) {
    // Calculate subtotal
    cart.subtotal = cart.items.reduce(
      (sum, item) => sum + (item.price * item.quantity), 
      0
    );

    // Calculate total
    cart.total = cart.subtotal + cart.shipping + cart.tax;

    this.carts.set(cart.id, cart);
  }

  // Newsletter methods
  async subscribeToNewsletter(email: string): Promise<Newsletter> {
    // Check if email already exists
    const exists = Array.from(this.newsletters.values()).some(
      (newsletter) => newsletter.email === email
    );

    if (exists) {
      throw new Error("Email already subscribed");
    }

    const id = this.newsletterIdCounter++;
    const newsletter: Newsletter = {
      id,
      email,
      createdAt: new Date(),
    };

    this.newsletters.set(id, newsletter);
    return newsletter;
  }
}

export const storage = new MemStorage();