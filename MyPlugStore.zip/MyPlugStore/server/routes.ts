import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertNewsletterSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { initiateSTKPush, querySTKStatus, formatPhoneNumber } from "./mpesa";
import { registerAdminRoutes } from "./admin-routes";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  
  // Register admin routes
  registerAdminRoutes(app);
  
  // Get all categories
  app.get("/api/categories", async (_req: Request, res: Response) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });
  
  // Get category by slug
  app.get("/api/categories/:slug", async (req: Request, res: Response) => {
    const category = await storage.getCategoryBySlug(req.params.slug);
    
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }
    
    res.json(category);
  });
  
  // Get all products with optional filtering
  app.get("/api/products", async (req: Request, res: Response) => {
    try {
      const querySchema = z.object({
        category: z.string().optional(),
        featured: z.enum(["true", "false"]).optional(),
        trending: z.enum(["true", "false"]).optional(),
        limit: z.string().regex(/^\d+$/).optional(),
        search: z.string().optional(),
      });
      
      const query = querySchema.parse(req.query);
      
      const options: {
        categoryId?: number;
        featured?: boolean;
        trending?: boolean;
        limit?: number;
        search?: string;
      } = {};
      
      if (query.category) {
        const category = await storage.getCategoryBySlug(query.category);
        if (category) {
          options.categoryId = category.id;
        }
      }
      
      if (query.featured) {
        options.featured = query.featured === "true";
      }
      
      if (query.trending) {
        options.trending = query.trending === "true";
      }
      
      if (query.limit) {
        options.limit = parseInt(query.limit, 10);
      }
      
      if (query.search) {
        options.search = query.search;
      }
      
      const products = await storage.getProducts(options);
      
      // Get category names for each product
      const productsWithCategories = await Promise.all(products.map(async (product) => {
        const category = await storage.getCategory(product.categoryId);
        return {
          ...product,
          categoryName: category ? category.name : "Unknown",
        };
      }));
      
      res.json(productsWithCategories);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid query parameters",
          errors: fromZodError(error).message
        });
      }
      throw error;
    }
  });
  
  // Get product by slug
  app.get("/api/products/:slug", async (req: Request, res: Response) => {
    const product = await storage.getProductBySlug(req.params.slug);
    
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    
    const category = await storage.getCategory(product.categoryId);
    
    res.json({
      ...product,
      categoryName: category ? category.name : "Unknown",
    });
  });
  
  // Cart management
  // Create a new cart
  app.post("/api/cart", async (_req: Request, res: Response) => {
    const cart = await storage.createCart();
    res.json(cart);
  });
  
  // Get cart by ID
  app.get("/api/cart/:id", async (req: Request, res: Response) => {
    const cart = await storage.getCart(req.params.id);
    
    if (!cart) {
      return res.status(404).json({ message: "Cart not found" });
    }
    
    res.json(cart);
  });
  
  // Add item to cart
  app.post("/api/cart/:id/items", async (req: Request, res: Response) => {
    try {
      const bodySchema = z.object({
        productId: z.number(),
        quantity: z.number().min(1),
      });
      
      const { productId, quantity } = bodySchema.parse(req.body);
      
      const cart = await storage.addToCart(req.params.id, productId, quantity);
      res.json(cart);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid request body",
          errors: fromZodError(error).message
        });
      }
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      throw error;
    }
  });
  
  // Update cart item
  app.put("/api/cart/:id/items/:itemId", async (req: Request, res: Response) => {
    try {
      const bodySchema = z.object({
        quantity: z.number().min(0),
      });
      
      const { quantity } = bodySchema.parse(req.body);
      const itemId = parseInt(req.params.itemId, 10);
      
      if (isNaN(itemId)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }
      
      const cart = await storage.updateCartItem(req.params.id, itemId, quantity);
      res.json(cart);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid request body",
          errors: fromZodError(error).message
        });
      }
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      throw error;
    }
  });
  
  // Remove item from cart
  app.delete("/api/cart/:id/items/:itemId", async (req: Request, res: Response) => {
    try {
      const itemId = parseInt(req.params.itemId, 10);
      
      if (isNaN(itemId)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }
      
      const cart = await storage.removeFromCart(req.params.id, itemId);
      res.json(cart);
    } catch (error) {
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      throw error;
    }
  });
  
  // Newsletter subscription
  app.post("/api/newsletter", async (req: Request, res: Response) => {
    try {
      const data = insertNewsletterSchema.parse(req.body);
      
      const newsletter = await storage.subscribeToNewsletter(data.email);
      res.json(newsletter);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid request body",
          errors: fromZodError(error).message
        });
      }
      if (error instanceof Error) {
        return res.status(400).json({ message: error.message });
      }
      throw error;
    }
  });

  // M-Pesa STK Push endpoint
  app.post("/api/mpesa/stkpush", async (req: Request, res: Response) => {
    try {
      const bodySchema = z.object({
        phoneNumber: z.string().min(9, "Phone number is required"),
        amount: z.number().min(1, "Amount must be at least 1 KSh"),
        accountReference: z.string().min(1, "Account reference is required"),
        transactionDesc: z.string().optional().default("Payment for THE PLUG order")
      });

      const { phoneNumber, amount, accountReference, transactionDesc } = bodySchema.parse(req.body);
      
      // Format phone number for validation
      const formattedPhone = formatPhoneNumber(phoneNumber);
      if (!formattedPhone.match(/^254[17]\d{8}$/)) {
        return res.status(400).json({ 
          message: "Invalid phone number format. Use format like 0712345678 or 254712345678" 
        });
      }

      const result = await initiateSTKPush(phoneNumber, amount, accountReference, transactionDesc);
      
      res.json({
        success: true,
        message: "STK Push initiated successfully. Check your phone for payment prompt.",
        data: result
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data",
          errors: fromZodError(error).message
        });
      }
      if (error instanceof Error) {
        return res.status(500).json({ 
          message: error.message,
          success: false 
        });
      }
      return res.status(500).json({ 
        message: "STK Push failed",
        success: false 
      });
    }
  });

  // M-Pesa callback endpoint
  app.post("/api/mpesa/callback", async (req: Request, res: Response) => {
    try {
      console.log("M-Pesa Callback received:", JSON.stringify(req.body, null, 2));
      
      const { Body } = req.body;
      
      if (Body && Body.stkCallback) {
        const callback = Body.stkCallback;
        const resultCode = callback.ResultCode;
        
        if (resultCode === 0) {
          // Payment successful
          console.log("✅ Payment successful:", {
            MerchantRequestID: callback.MerchantRequestID,
            CheckoutRequestID: callback.CheckoutRequestID,
            Amount: callback.CallbackMetadata?.Item?.find((item: any) => item.Name === 'Amount')?.Value,
            MpesaReceiptNumber: callback.CallbackMetadata?.Item?.find((item: any) => item.Name === 'MpesaReceiptNumber')?.Value,
            TransactionDate: callback.CallbackMetadata?.Item?.find((item: any) => item.Name === 'TransactionDate')?.Value,
            PhoneNumber: callback.CallbackMetadata?.Item?.find((item: any) => item.Name === 'PhoneNumber')?.Value
          });
          
          // Here you would typically update your order status in the database
          // For now, we'll just log the successful payment
        } else {
          // Payment failed
          console.log("❌ Payment failed:", {
            MerchantRequestID: callback.MerchantRequestID,
            CheckoutRequestID: callback.CheckoutRequestID,
            ResultCode: callback.ResultCode,
            ResultDesc: callback.ResultDesc
          });
        }
      }
      
      // Always respond with success to acknowledge receipt
      res.json({ 
        ResultCode: 0, 
        ResultDesc: "Accepted" 
      });
    } catch (error) {
      console.error("Callback processing error:", error);
      // Still respond with success to avoid M-Pesa retries
      res.json({ 
        ResultCode: 0, 
        ResultDesc: "Accepted" 
      });
    }
  });

  // STK Push status query endpoint
  app.get("/api/mpesa/status/:checkoutRequestID", async (req: Request, res: Response) => {
    try {
      const { checkoutRequestID } = req.params;
      
      if (!checkoutRequestID) {
        return res.status(400).json({ 
          message: "Checkout Request ID is required" 
        });
      }

      const result = await querySTKStatus(checkoutRequestID);
      res.json(result);
    } catch (error) {
      if (error instanceof Error) {
        return res.status(500).json({ 
          message: error.message 
        });
      }
      return res.status(500).json({ 
        message: "Failed to query payment status" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
