import axios from 'axios';

// M-Pesa Sandbox Credentials (for testing)
const CONSUMER_KEY = "NBGglWGhPa9Q4pUlcIGnJQLCXjkFDfCf";
const CONSUMER_SECRET = "7kgCDDdXMANAWb4E";
const BUSINESS_SHORTCODE = "174379";
const PASSKEY = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";
const BASE_URL = "https://sandbox.safaricom.co.ke";
const CALLBACK_URL = process.env.REPL_ID ? `https://${process.env.REPL_ID}.replit.dev/api/mpesa/callback` : "https://your-domain.com/api/mpesa/callback";

interface MpesaResponse {
  MerchantRequestID: string;
  CheckoutRequestID: string;
  ResponseCode: string;
  ResponseDescription: string;
  CustomerMessage: string;
}

// Generate Access Token
async function generateAccessToken(): Promise<string> {
  const auth = Buffer.from(`${CONSUMER_KEY}:${CONSUMER_SECRET}`).toString('base64');

  try {
    const response = await axios.get(
      `${BASE_URL}/oauth/v1/generate?grant_type=client_credentials`,
      {
        headers: {
          Authorization: `Basic ${auth}`
        }
      }
    );
    return response.data.access_token;
  } catch (error) {
    console.error('Token generation failed:', error);
    throw new Error('Failed to generate access token');
  }
}

// Generate Password for STK Push
function generatePassword(): { password: string; timestamp: string } {
  const timestamp = new Date().toISOString()
    .replace(/[^0-9]/g, '')
    .slice(0, -3);
  
  const password = Buffer.from(
    BUSINESS_SHORTCODE + PASSKEY + timestamp
  ).toString('base64');

  return { password, timestamp };
}

// Format phone number to 254XXXXXXXXX format
function formatPhoneNumber(phoneNumber: string): string {
  // Remove any spaces, hyphens, or plus signs
  let cleaned = phoneNumber.replace(/[\s\-\+]/g, '');
  
  // Handle different formats
  if (cleaned.startsWith('0')) {
    // Convert 0712345678 to 254712345678
    return '254' + cleaned.slice(1);
  } else if (cleaned.startsWith('7') || cleaned.startsWith('1')) {
    // Convert 712345678 to 254712345678
    return '254' + cleaned;
  } else if (cleaned.startsWith('254')) {
    // Already in correct format
    return cleaned;
  }
  
  // Default case - assume it needs 254 prefix
  return '254' + cleaned;
}

// Initiate STK Push
export async function initiateSTKPush(
  phoneNumber: string,
  amount: number,
  accountReference: string,
  transactionDesc: string
): Promise<MpesaResponse> {
  try {
    const token = await generateAccessToken();
    const { password, timestamp } = generatePassword();
    const formattedPhone = formatPhoneNumber(phoneNumber);

    const payload = {
      BusinessShortCode: BUSINESS_SHORTCODE,
      Password: password,
      Timestamp: timestamp,
      TransactionType: "CustomerPayBillOnline",
      Amount: Math.round(amount), // Ensure amount is integer
      PartyA: formattedPhone,
      PartyB: BUSINESS_SHORTCODE,
      PhoneNumber: formattedPhone,
      CallBackURL: CALLBACK_URL,
      AccountReference: accountReference,
      TransactionDesc: transactionDesc
    };

    console.log('STK Push payload:', JSON.stringify(payload, null, 2));

    const response = await axios.post(
      `${BASE_URL}/mpesa/stkpush/v1/processrequest`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return response.data;
  } catch (error: any) {
    console.error('STK Push failed:', error.response?.data || error.message);
    throw new Error(error.response?.data?.errorMessage || 'STK Push request failed');
  }
}

// Query STK Push transaction status
export async function querySTKStatus(checkoutRequestID: string): Promise<any> {
  try {
    const token = await generateAccessToken();
    const { password, timestamp } = generatePassword();

    const payload = {
      BusinessShortCode: BUSINESS_SHORTCODE,
      Password: password,
      Timestamp: timestamp,
      CheckoutRequestID: checkoutRequestID
    };

    const response = await axios.post(
      `${BASE_URL}/mpesa/stkpushquery/v1/query`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return response.data;
  } catch (error: any) {
    console.error('STK Query failed:', error.response?.data || error.message);
    throw new Error('Failed to query transaction status');
  }
}

export { formatPhoneNumber };